// SPDX-FileCopyrightText: 2026 Jake Wehmeier (BTSpaniel) <https://github.com/BTSpaniel>
//
// SPDX-License-Identifier: LicenseRef-ParticleRealms-Alpha

/**
 * boot-theme.js — early theme bootstrap (pre-paint, classic script).
 *
 * Loaded synchronously in <head> BEFORE the stylesheet so the saved accent /
 * radius / blur / font are applied before first paint (no flash of default
 * theme). Kept as an EXTERNAL classic script (not inline) so the OS shell can
 * ship a strict Content-Security-Policy with `script-src 'self'` — no
 * `'unsafe-inline'` needed. Must stay dependency-free and side-effect-local.
 */
(function () {
    try {
        var a = JSON.parse(localStorage.getItem('os.appearance') || '{}');
        var TH  = { dark: '#5b7cff', ocean: '#06b6d4', forest: '#22c55e', crimson: '#ef4444', violet: '#a855f7', midnight: '#818cf8', amber: '#f59e0b', rose: '#f43f5e' };
        var TH2 = { dark: '#1fd2b4', ocean: '#3b82f6', forest: '#84cc16', crimson: '#f97316', violet: '#ec4899', midnight: '#6366f1', amber: '#ef4444', rose: '#ec4899' };
        var accent  = a.customAccent || (a.themeId && TH[a.themeId]) || '#5b7cff';
        var accent2 = a.customAccent ? (a.customAccent + 'aa') : ((a.themeId && TH2[a.themeId]) || '#1fd2b4');
        var r = document.documentElement;
        var legacyMode = localStorage.getItem('os.theme');
        var mode = a.colorMode || (legacyMode === 'light' ? 'light' : 'dark');
        var resolvedMode = mode === 'system'
            ? (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark')
            : mode;
        var reduceMotion = a.motionMode === 'reduce'
            || (a.motionMode !== 'full' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches)
            || a.reducedMotion === true;
        r.classList.toggle('theme-light', resolvedMode === 'light');
        r.classList.toggle('theme-dark', resolvedMode !== 'light');
        r.style.setProperty('--os-color-scheme', resolvedMode);
        r.style.colorScheme = resolvedMode;
        r.style.setProperty('--os-accent',       accent);
        r.style.setProperty('--os-accent-2',     accent2);
        r.style.setProperty('--color-primary',   accent);
        r.style.setProperty('--color-secondary', accent2);
        if (a.radius) r.style.setProperty('--os-radius', a.radius);
        if (a.blur !== undefined) r.style.setProperty('--os-blur', a.blur + 'px');
        if (a.animations === false) r.style.setProperty('--os-anim-dur', '0s');
        if (a.fontFamily) r.style.setProperty('--os-font', a.fontFamily);
        if (a.fontSize) r.style.fontSize = a.fontSize;
        if (Number.isFinite(Number(a.taskbarHeight))) r.style.setProperty('--os-taskbar-h', Math.max(44, Math.min(88, Number(a.taskbarHeight))) + 'px');
        else {
            var display = JSON.parse(localStorage.getItem('os.display') || '{}');
            if (Number.isFinite(Number(display.taskbarH))) r.style.setProperty('--os-taskbar-h', Math.max(44, Math.min(88, Number(display.taskbarH))) + 'px');
        }
        if (reduceMotion) r.classList.add('reduce-motion');
    } catch (e) { /* appearance not set yet — defaults apply */ }

    // Embedding preference: isolated (credentialless) iframe mode. When ON, the
    // browser/compat layer embeds cross-origin sites in an ephemeral, cookieless
    // context (works even under OS cross-origin isolation) at the cost of no
    // shared login. Read here so it is set before any app/iframe is created.
    // A settings toggle persists `os.embed = { credentialless: true }`.
    try {
        var e = JSON.parse(localStorage.getItem('os.embed') || '{}');
        if (e && e.credentialless) globalThis.__OS_EMBED_CREDENTIALLESS__ = true;
        // preferLive: force wrapped cross-origin apps to load on their own origin
        // (cookies / Web Locks / storage work). Auto-detect handles most cases;
        // this is the global override. A per-app `profile.preferLive` takes
        // precedence (incl. `false` to force the sandbox).
        if (e && e.preferLive) globalThis.__OS_EMBED_PREFER_LIVE__ = true;
    } catch (e2) { /* default OFF — cookie-preserving embedding */ }
})();

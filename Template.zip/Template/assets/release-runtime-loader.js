// SPDX-FileCopyrightText: 2026 Jake Wehmeier (BTSpaniel) <https://github.com/BTSpaniel>
//
// SPDX-License-Identifier: LicenseRef-ParticleRealms-Alpha

// CSP-safe compressed runtime loader. Configuration is supplied through data-*
// attributes on this external script. The browser fetches the build-produced
// gzip asset, expands it with DecompressionStream, verifies the exact decoded
// byte length and SHA-384 SRI identity, then executes it from a Blob URL.
(() => {
  if (globalThis.__PE_RUNTIME_READY?.then) return;
  const config = document.currentScript;
  const ready = (async () => {
    if (!config) {
      throw new Error('Release runtime loader could not resolve its script element');
    }

    const runtimeSource = config.dataset.runtimeSrc;
    const assetBase = config.dataset.assetBase;
    const runtimeBase = config.dataset.runtimeBase;
    const integrity = config.dataset.integrity;
    const runtimeBytes = Number(config.dataset.runtimeBytes);
    if (!runtimeSource || !assetBase || !runtimeBase || !integrity ||
        !Number.isSafeInteger(runtimeBytes) || runtimeBytes <= 0) {
      throw new Error('Release runtime loader configuration is incomplete');
    }
    if (!/^sha384-[A-Za-z0-9+/]{64}$/.test(integrity)) {
      throw new Error('Release runtime loader received an invalid SHA-384 identity');
    }
    if (!globalThis.crypto?.subtle) {
      throw new Error('Release runtime verification requires Web Crypto');
    }

    globalThis.__PE_ASSET_BASE = new URL(assetBase, document.baseURI).href;
    const resolvedRuntimeBase = new URL(runtimeBase, document.baseURI).href;
    const configuredBases = globalThis.__PE_RUNTIME_BASES__ || {};
    globalThis.__PE_RUNTIME_BASES__ = Object.freeze({
      engine: configuredBases.engine || new URL('engine/', resolvedRuntimeBase).href,
      editor: configuredBases.editor || new URL('editor/', resolvedRuntimeBase).href,
      plauna: configuredBases.plauna || new URL('plauna/', resolvedRuntimeBase).href,
      agi: configuredBases.agi || new URL('agi/', resolvedRuntimeBase).href,
    });
    if (config.dataset.osBase) {
      globalThis.__PE_OS_BASE__ = new URL(config.dataset.osBase, document.baseURI).href;
    }

    const existingApi = globalThis.PE || globalThis.ParticleEngine;
    if (existingApi && typeof existingApi.__require === 'function' && existingApi.__modules) {
      if (!globalThis.PE) globalThis.PE = existingApi;
      return existingApi;
    }

    const runtimeUrl = new URL(runtimeSource, document.baseURI);
    const response = await fetch(runtimeUrl, {
      cache: 'force-cache',
      credentials: 'same-origin',
    });
    if (!response.ok) {
      throw new Error(`Compressed runtime fetch failed (${response.status}): ${runtimeUrl.href}`);
    }

    const payload = new Uint8Array(await response.arrayBuffer());
    const isGzip = payload.length >= 2 && payload[0] === 0x1f && payload[1] === 0x8b;
    let sourceBytes;
    if (isGzip) {
      if (typeof DecompressionStream !== 'function') {
        throw new Error("Compressed runtime requires DecompressionStream('gzip')");
      }
      const reader = new Blob([payload]).stream()
        .pipeThrough(new DecompressionStream('gzip'))
        .getReader();
      const chunks = [];
      let decodedBytes = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        decodedBytes += value.byteLength;
        if (decodedBytes > runtimeBytes) {
          try { await reader.cancel(); } catch {}
          throw new Error(`Compressed runtime expands beyond ${runtimeBytes} verified bytes`);
        }
        chunks.push(value);
      }
      if (decodedBytes !== runtimeBytes) {
        throw new Error(`Compressed runtime decoded ${decodedBytes} bytes; expected ${runtimeBytes}`);
      }
      sourceBytes = new Uint8Array(decodedBytes);
      let offset = 0;
      for (const chunk of chunks) {
        sourceBytes.set(chunk, offset);
        offset += chunk.byteLength;
      }
    } else {
      if (payload.byteLength !== runtimeBytes) {
        throw new Error(`Runtime response has ${payload.byteLength} bytes; expected ${runtimeBytes}`);
      }
      sourceBytes = payload;
    }

    const digest = new Uint8Array(await crypto.subtle.digest('SHA-384', sourceBytes));
    const actualIntegrity = `sha384-${btoa(String.fromCharCode(...digest))}`;
    if (actualIntegrity !== integrity) {
      throw new Error('Compressed runtime failed SHA-384 verification');
    }

    const blobUrl = URL.createObjectURL(new Blob([sourceBytes], { type: 'text/javascript' }));
    try {
      await new Promise((resolve, reject) => {
        const runtime = document.createElement('script');
        runtime.src = blobUrl;
        runtime.async = true;
        runtime.addEventListener('load', resolve, { once: true });
        runtime.addEventListener('error', () => {
          reject(new Error(`Verified runtime failed to execute: ${runtimeUrl.href}`));
        }, { once: true });
        document.head.appendChild(runtime);
      });
    } finally {
      URL.revokeObjectURL(blobUrl);
    }

    const api = globalThis.PE || globalThis.ParticleEngine;
    if (!api || typeof api.__require !== 'function' || !api.__modules) {
      throw new Error('Compiled runtime loaded without a complete Particle Engine registry');
    }
    if (!globalThis.PE) globalThis.PE = api;
    return api;
  })();

  ready.catch((error) => console.error('[Release] Runtime unavailable:', error));
  globalThis.__PE_RUNTIME_READY = ready;
})();

// SPDX-FileCopyrightText: 2026 Jake Wehmeier (BTSpaniel) <https://github.com/BTSpaniel>
//
// SPDX-License-Identifier: LicenseRef-ParticleRealms-Alpha

// CSP-safe compressed runtime loader. Configuration is supplied through data-*
// attributes on this external script. The browser fetches the build-produced
// gzip asset, expands it with DecompressionStream, verifies the exact decoded
// byte length and SHA-384 SRI identity, then executes it from a Blob URL.
(() => {
  if (globalThis.__PE_RUNTIME_READY?.then) return;
  const config = document.currentScript;
  const hasRuntimeRegistry = (api) => !!(
    api
    && typeof (api.requireModule || api.__require || api._require) === 'function'
    && (api.__modules || api._M)
  );
  const ready = (async () => {
    if (!config) {
      throw new Error('Release runtime loader could not resolve its script element');
    }

    const runtimeSource = config.dataset.runtimeSrc;
    const assetBase = config.dataset.assetBase;
    const runtimeBase = config.dataset.runtimeBase;
    const integrity = config.dataset.integrity;
    const runtimeBytes = Number(config.dataset.runtimeBytes);
    const runtimeCompressedBytes = Number(config.dataset.runtimeCompressedBytes);
    if (!runtimeSource || !assetBase || !runtimeBase || !integrity ||
        !Number.isSafeInteger(runtimeBytes) || runtimeBytes <= 0 ||
        !Number.isSafeInteger(runtimeCompressedBytes) || runtimeCompressedBytes <= 0) {
      throw new Error('Release runtime loader configuration is incomplete');
    }
    if (!/^sha384-[A-Za-z0-9+/]{64}$/.test(integrity)) {
      throw new Error('Release runtime loader received an invalid SHA-384 identity');
    }
    if (!globalThis.crypto?.subtle) {
      throw new Error('Release runtime verification requires Web Crypto');
    }

    globalThis.__PE_ASSET_BASE = new URL(assetBase, document.baseURI).href;
    const resolvedRuntimeBase = new URL(runtimeBase, document.baseURI).href;
    const configuredBases = globalThis.__PE_RUNTIME_BASES__ || {};
    globalThis.__PE_RUNTIME_BASES__ = Object.freeze({
      engine: configuredBases.engine || new URL('engine/', resolvedRuntimeBase).href,
      editor: configuredBases.editor || new URL('editor/', resolvedRuntimeBase).href,
      plauna: configuredBases.plauna || new URL('plauna/', resolvedRuntimeBase).href,
      agi: configuredBases.agi || new URL('agi/', resolvedRuntimeBase).href,
    });
    if (config.dataset.osBase) {
      globalThis.__PE_OS_BASE__ = new URL(config.dataset.osBase, document.baseURI).href;
    }

    const existingApi = globalThis.PE || globalThis.ParticleEngine;
    if (hasRuntimeRegistry(existingApi)) {
      if (!globalThis.PE) globalThis.PE = existingApi;
      return existingApi;
    }

    const runtimeUrl = new URL(runtimeSource, document.baseURI);
    const controller = new AbortController();
    const timeout = globalThis.setTimeout(() => controller.abort(), 120000);
    let payload;
    try {
      const response = await fetch(runtimeUrl, {
        cache: 'force-cache',
        credentials: 'same-origin',
        signal: controller.signal,
      });
      if (!response.ok) {
        throw new Error(`Compressed runtime fetch failed (${response.status}): ${runtimeUrl.href}`);
      }

      const declaredLength = Number(response.headers.get('content-length'));
      if (Number.isFinite(declaredLength) && declaredLength > 0 &&
          declaredLength !== runtimeCompressedBytes && declaredLength !== runtimeBytes) {
        throw new Error(`Runtime response declares ${declaredLength} bytes; expected ${runtimeCompressedBytes} compressed bytes`);
      }
      if (!response.body) {
        throw new Error('Compressed runtime response has no readable body');
      }
      const responseReader = response.body.getReader();
      const responseChunks = [];
      const maxResponseBytes = Math.max(runtimeCompressedBytes, runtimeBytes);
      let receivedBytes = 0;
      for (;;) {
        const { done, value } = await responseReader.read();
        if (done) break;
        receivedBytes += value.byteLength;
        if (receivedBytes > maxResponseBytes) {
          try { await responseReader.cancel(); } catch {}
          throw new Error(`Runtime response exceeds its ${maxResponseBytes}-byte safety bound`);
        }
        responseChunks.push(value);
      }
      payload = new Uint8Array(receivedBytes);
      let responseOffset = 0;
      for (const chunk of responseChunks) {
        payload.set(chunk, responseOffset);
        responseOffset += chunk.byteLength;
      }
    } catch (error) {
      if (error?.name === 'AbortError') {
        throw new Error(`Compressed runtime fetch timed out: ${runtimeUrl.href}`);
      }
      throw error;
    } finally {
      globalThis.clearTimeout(timeout);
    }
    const isGzip = payload.length >= 2 && payload[0] === 0x1f && payload[1] === 0x8b;
    let sourceBytes;
    if (isGzip) {
      if (payload.byteLength !== runtimeCompressedBytes) {
        throw new Error(`Compressed runtime has ${payload.byteLength} bytes; expected ${runtimeCompressedBytes}`);
      }
      if (typeof DecompressionStream !== 'function') {
        throw new Error("Compressed runtime requires DecompressionStream('gzip')");
      }
      const reader = new Blob([payload]).stream()
        .pipeThrough(new DecompressionStream('gzip'))
        .getReader();
      const chunks = [];
      let decodedBytes = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        decodedBytes += value.byteLength;
        if (decodedBytes > runtimeBytes) {
          try { await reader.cancel(); } catch {}
          throw new Error(`Compressed runtime expands beyond ${runtimeBytes} verified bytes`);
        }
        chunks.push(value);
      }
      if (decodedBytes !== runtimeBytes) {
        throw new Error(`Compressed runtime decoded ${decodedBytes} bytes; expected ${runtimeBytes}`);
      }
      sourceBytes = new Uint8Array(decodedBytes);
      let offset = 0;
      for (const chunk of chunks) {
        sourceBytes.set(chunk, offset);
        offset += chunk.byteLength;
      }
    } else {
      // A host may apply Content-Encoding to the .gz object and Fetch then
      // exposes the already-decoded response. Accept only the exact verified
      // source length so this cannot silently become an arbitrary text fallback.
      if (payload.byteLength !== runtimeBytes) {
        throw new Error(`Runtime response has ${payload.byteLength} bytes; expected ${runtimeBytes}`);
      }
      sourceBytes = payload;
    }

    const digest = new Uint8Array(await crypto.subtle.digest('SHA-384', sourceBytes));
    const actualIntegrity = `sha384-${btoa(String.fromCharCode(...digest))}`;
    if (actualIntegrity !== integrity) {
      throw new Error('Compressed runtime failed SHA-384 verification');
    }

    const blobUrl = URL.createObjectURL(new Blob([sourceBytes], { type: 'text/javascript' }));
    let executionError = null;
    const captureExecutionError = (event) => {
      if (event.filename !== blobUrl) return;
      const location = event.lineno ? ` at ${event.lineno}:${event.colno || 0}` : '';
      executionError = new Error(`Verified runtime syntax failure${location}: ${event.message || 'unknown script error'}`);
    };
    globalThis.addEventListener('error', captureExecutionError, true);
    try {
      await new Promise((resolve, reject) => {
        const runtime = document.createElement('script');
        runtime.src = blobUrl;
        runtime.async = true;
        runtime.addEventListener('load', resolve, { once: true });
        runtime.addEventListener('error', () => {
          queueMicrotask(() => reject(executionError || new Error(`Verified runtime failed to execute: ${runtimeUrl.href}`)));
        }, { once: true });
        document.head.appendChild(runtime);
      });
    } finally {
      globalThis.removeEventListener('error', captureExecutionError, true);
      URL.revokeObjectURL(blobUrl);
    }
    if (executionError) throw executionError;

    const api = globalThis.PE || globalThis.ParticleEngine;
    if (!hasRuntimeRegistry(api)) {
      throw new Error('Compiled runtime loaded without a complete Particle Engine registry');
    }
    if (!globalThis.PE) globalThis.PE = api;
    return api;
  })();

  // Engine-backed Playground demos and generated app launchers await the same
  // promise. Attach a rejection observer immediately so a failed network load
  // cannot become an unhandled rejection before those consumers execute.
  ready.catch((error) => console.error('[Release] Runtime unavailable:', error));
  globalThis.__PE_RUNTIME_READY = ready;
})();

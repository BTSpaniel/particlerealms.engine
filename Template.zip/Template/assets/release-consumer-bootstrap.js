// SPDX-FileCopyrightText: 2026 Jake Wehmeier (BTSpaniel) <https://github.com/BTSpaniel>
// SPDX-License-Identifier: LicenseRef-ParticleRealms-Alpha

// Bundler-managed Template bootstrap. It resolves subsystem namespaces from the
// verified platform runtime and fails visibly when a release contract drifts.
(() => {
  const status = document.getElementById('os-boot-status');
  const loader = document.getElementById('os-boot-loader');
  const selector = document.getElementById('boot-selector');

  const fail = (error) => {
    console.error('[Boot] Bundle failed:', error);
    if (status) status.textContent = 'Boot failed';
    const card = loader?.querySelector('.boot-card');
    if (!card) return;
    const el = document.createElement('div');
    el.className = 'error';
    el.setAttribute('role', 'alert');
    el.textContent = error?.message || String(error);
    card.appendChild(el);
  };

  const requireFunction = (owner, name, subsystem) => {
    const value = owner?.[name];
    if (typeof value !== 'function') {
      throw new Error(`Platform bundle is missing ${subsystem}.${name}`);
    }
    return value;
  };

  Promise.resolve(globalThis.__PE_RUNTIME_READY).then((runtime) => {
    const api = runtime || globalThis.PE || globalThis.ParticleEngine;
    if (!api) throw new Error('Particle Engine runtime not found after bundle load');
    const os = api.WebGPUOS || api;
    const plauna = api.Plauna || api;
    const bootWebGpuOS = requireFunction(os, 'bootWebGpuOS', 'WebGPUOS');
    const mountShowcaseApp = plauna.mountShowcaseApp;
    const ShowcaseApp = plauna.ShowcaseApp;
    if (typeof mountShowcaseApp !== 'function' && typeof ShowcaseApp !== 'function') {
      throw new Error('Platform bundle is missing Plauna.mountShowcaseApp/ShowcaseApp');
    }
    if (!api.Engine) throw new Error('Platform bundle is missing Engine');

    if (status) status.textContent = 'Bundle ready';
    selector?.classList.add('visible');
    selector?.addEventListener('click', async (event) => {
      const button = event.target.closest('[data-mode]');
      if (!button) return;
      selector.classList.remove('visible');
      const mode = button.dataset.mode;
      if (mode === 'os') {
        if (status) status.textContent = 'Starting kernel...';
        await bootWebGpuOS();
        return;
      }
      if (mode === 'plauna') {
        if (status) status.textContent = 'Starting Plauna Showcase...';
        const root = document.getElementById('plauna-root');
        if (root) root.style.display = '';
        if (typeof mountShowcaseApp === 'function') {
          await mountShowcaseApp({ root, statusElement: status });
        } else {
          const app = new ShowcaseApp({ root, statusElement: status });
          await app.boot();
        }
        loader?.remove();
        return;
      }
      if (mode === 'canvas') {
        if (status) status.textContent = 'Engine ready';
        const root = document.getElementById('canvas-root');
        if (root) root.style.display = '';
        loader?.remove();
      }
    });
  }).catch(fail);
})();

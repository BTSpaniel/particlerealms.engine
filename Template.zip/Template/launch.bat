@echo off
title Particle Realms - Platform
color 07

echo.
echo   Particle Realms
echo   Platform Launcher
echo.

set "PORT=8000"
set "SCRIPT_DIR=%~dp0"

:parse
if "%~1"=="" goto done_parse
if "%~1"=="--port" (
    set "PORT=%~2"
    shift
    shift
    goto parse
)
if "%~1"=="-p" (
    set "PORT=%~2"
    shift
    shift
    goto parse
)
shift
goto parse

:done_parse

where python >nul 2>&1
if %errorlevel% neq 0 (
    echo   [ERROR] Python not found on PATH.
    pause
    exit /b 1
)

echo   Port: %PORT%
echo   Opening browser...
echo.

start "" http://127.0.0.1:%PORT%
python "%SCRIPT_DIR%serve.py" %PORT%

exit /b 0

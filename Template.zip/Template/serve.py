#!/usr/bin/env python3
"""
Particle Realms — Platform Server

Static file server for the platform template with:
  - COOP/COEP headers (required for WebGPU cross-origin isolation)
  - Threaded request handling
  - Watchdog auto-restart on unhandled server errors

Usage:
  python serve.py [port]
"""
import http.server
import socketserver
import sys
import os
import time

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
HOST = "127.0.0.1"
ROOT = os.path.dirname(os.path.abspath(__file__))
MAX_RESTART_DELAY = 10

os.chdir(ROOT)


class PlatformHandler(http.server.SimpleHTTPRequestHandler):
    """Serves static files with the headers WebGPU isolation requires."""

    def end_headers(self):
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Cross-Origin-Embedder-Policy", "require-corp")
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def log_message(self, *args):
        pass  # keep stdout clean; enable for debugging if needed


class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def run_server():
    with ThreadingHTTPServer((HOST, PORT), PlatformHandler) as httpd:
        httpd.serve_forever()


def main():
    print(f"Particle Realms — Platform Server")
    print(f"Serving {ROOT}")
    print(f"Listening on http://{HOST}:{PORT}")
    print(f"Press Ctrl+C to stop.\n")

    restart_delay = 1
    while True:
        try:
            run_server()
            return  # serve_forever only returns on shutdown()
        except KeyboardInterrupt:
            print("\nStopped.")
            return
        except OSError as e:
            print(f"Failed to bind to port {PORT}: {e}")
            print(f"Try a different port: python serve.py 9001")
            sys.exit(1)
        except Exception as e:
            print(f"Server error: {e}")
            print(f"Restarting in {restart_delay}s...")
            time.sleep(restart_delay)
            restart_delay = min(restart_delay * 2, MAX_RESTART_DELAY)


if __name__ == "__main__":
    main()

# Template App

A minimal, installable WebGPU-OS app. Copy this folder, rename the `id`, edit
`files/index.js`, then package and install it.

## Layout

```
template-app/
  manifest.json      ← prpkg manifest (id, name, entry, permissions, …)
  files/
    index.js         ← the app: default-exported class with mount(root, syscalls)
```

An app is an ES module whose **default export** is a class with an async
`mount(root, syscalls)` method. Relative imports between packaged files are
supported (the loader rewrites them to blob URLs).

## Package it

Use **Package Studio** in Developer Tools. It fills the files and provenance for
you, signs through the guarded `crypto` syscall, and installs through the guarded
`pkg` syscall.

## Install it

- **From the envelope URL** (recommended): the `.prpkg.json` sidecar references the
  sibling `.prpkg` binary. Install it through Package Manager or Package Studio.

- **From the binary URL**: the loader fetches the sibling `.prpkg.json` envelope
  automatically.

On first install of a self-signed package you'll get a **consent prompt** showing
the publisher fingerprint, trust verdict, scan risk, and requested permissions.
Accepting **pins** the publisher (trust-on-first-use). The app then launches like a
built-in (its entry resolves via `pkg:os.template-app`).

## Trust & safety notes

- Packages run **no install-time scripts** — only your `mount()` runs, when the app
  is opened, inside the per-app sandbox with capability gating.
- Untrusted/unpinned packages get a **restricted profile**; quarantined packages are
  **denied network egress**.
- Declare only the `permissions` you actually use; the user must grant them.

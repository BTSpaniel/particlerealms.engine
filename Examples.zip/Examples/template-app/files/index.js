/**
 * Template App — a minimal installable WebGPU-OS app.
 *
 * An app is an ES module whose default export is a class with a `mount(root, syscalls)`
 * method. When packaged as a `.prpkg`, PackageLoader loads this file from OPFS as a
 * blob-URL module and the shell calls `new TemplateApp().mount(bodyEl, syscalls)`.
 *
 * Relative imports (e.g. `import { x } from './util.js'`) are supported — the loader
 * rewrites them to blob URLs of the sibling packaged files.
 */
export default class TemplateApp {
    async mount(root, syscalls) {
        root.innerHTML = '';
        root.style.cssText = 'display:flex;flex-direction:column;gap:12px;padding:20px;'
            + 'font-family:system-ui,sans-serif;color:var(--text-primary,#e6e6e6);'
            + 'background:var(--os-surface,#1a1a1a);height:100%;box-sizing:border-box;';

        const title = document.createElement('h2');
        title.textContent = 'Template App';
        title.style.margin = '0';

        const info = document.createElement('p');
        info.style.cssText = 'margin:0;opacity:0.8;font-size:13px;line-height:1.5;';
        info.textContent = 'This app was installed from a signed .prpkg and is running '
            + 'from OPFS via PackageLoader. Edit files/index.js, re-package, and reinstall.';

        const counter = document.createElement('button');
        let n = 0;
        counter.style.cssText = 'align-self:flex-start;padding:8px 16px;border-radius:6px;'
            + 'border:1px solid var(--border-light,#444);background:var(--os-hover,#2a2a2a);'
            + 'color:inherit;cursor:pointer;font-size:14px;';
        const render = () => { counter.textContent = `Clicked ${n} time${n === 1 ? '' : 's'}`; };
        render();
        counter.addEventListener('click', () => { n++; render(); });

        root.append(title, info, counter);
    }

    unmount() { /* optional cleanup */ }
}

/**
 * Template Mod — a minimal PatchBus mod.
 *
 * A mod default-exports a plain object whose methods are PatchBus hooks. They run
 * at runtime against the apps listed in manifest.targets (or ["*"] for all apps).
 * Mods are ordered by manifest.priority (lower runs first); when delivered as a
 * `.prpkg` of type "mod" they install through PackageManager into ModRegistry.
 *
 * Available hooks (all optional):
 *   patchManifest(appId, manifest)        → return a modified manifest
 *   beforeMount(appId, root, syscalls, manifest)
 *   afterMount(appId, root, syscalls, app, manifest)
 *   injectUI(appId, root, manifest)
 *   injectCSS(appId)                       → return a CSS string
 *   wrapSyscalls(appId, syscalls)          → return wrapped syscalls
 *   entryOverride: only honored if manifest.entryOverride === true
 */
export default {
    afterMount(appId, root /*, syscalls, app, manifest */) {
        const banner = document.createElement('div');
        banner.textContent = '✨ Modified by Template Mod';
        banner.style.cssText = 'padding:6px 10px;border-radius:6px;font-size:12px;'
            + 'background:var(--os-accent,#3b82f6);color:#fff;align-self:flex-start;';
        root.prepend(banner);
    },

    injectCSS(/* appId */) {
        return `/* template-mod CSS injection */`;
    },
};

# Template Mod

A minimal mod that hooks the runtime via `PatchBus`. Copy this folder, rename the
`modId`, set your `targets`, and edit `files/mod.js`.

## Layout

```
template-mod/
  manifest.json     ← modId, targets, entry, priority, entryOverride, enabled
  files/
    mod.js          ← default-exported object of PatchBus hooks
```

## Two ways to ship a mod

1. **Dev tree** — drop the folder in `mods/<name>/` and add `<name>` to
   `mods/index.json`. `ModRegistry` discovers and wires it into `PatchBus`.

2. **Installable package** — package it as a `.prpkg` with `manifest.type: "mod"`.
   `PackageManager.install()` registers it into `ModRegistry`/`PatchBus` just like a
   dev-tree mod. Build it the same way as an app (see `../template-app/README.md`),
   keeping the mod fields (`modId`, `targets`, `priority`).

## Ordering

Mods run in `priority` order (**lower runs first**, default 100). File-overlay
patches (`PatchManager`) and runtime hooks (`PatchBus`) share this explicit order so
stacking is predictable. Reorder installed patches/mods from
**Control Panel → Apps & Features → Patches**.

## Hooks

| Hook | When | Returns |
|------|------|---------|
| `patchManifest(appId, manifest)` | before launch | modified manifest |
| `beforeMount(appId, root, syscalls, manifest)` | before app mounts | — |
| `afterMount(appId, root, syscalls, app, manifest)` | after app mounts | — |
| `injectUI(appId, root, manifest)` | after mount | — |
| `injectCSS(appId)` | after mount | CSS string |
| `wrapSyscalls(appId, syscalls)` | at launch | wrapped syscalls |

Set `entryOverride: true` to completely replace an app's entry module with the
mod's own (fork-an-app pattern).

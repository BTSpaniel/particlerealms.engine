/**
 * PinballInput — maps keyboard + pointer to flipper / plunger actions.
 *
 * Keyboard: Z or ← = left flipper, / or → = right flipper, Space = charge &
 * release plunger. Pointer: left half of the playfield = left flipper, right
 * half = right flipper; pressing in the launch lane charges the plunger.
 *
 * Listeners are gated by `active` so the game only responds while its panel is
 * focused (set by PinballApp on focus/blur), and are fully removed on detach.
 */
const CHARGE_TIME_MS = 1100;

export class PinballInput {
    /**
     * @param {import('./PinballSimWorld.js').PinballSimWorld} sim
     * @param {HTMLElement} target  element receiving pointer events (overlay canvas)
     */
    constructor(sim, target, hooks = {}) {
        this.sim = sim;
        this.target = target;
        this.hooks = hooks; // { cycleDimension?: () => void }
        this.active = true;
        this._charging = false;
        this._chargeStart = 0;
        this._charge = 0;
        this._pointerSide = null;
        this._bound = {};
    }

    /** Current plunger charge [0..1] for the HUD. */
    get charge() { return this._charge; }

    attach() {
        const onKeyDown = (e) => {
            if (!this.active) return;
            if (e.key === 'z' || e.key === 'Z' || e.key === 'ArrowLeft')  { this.sim.setFlipper('left', true); }
            else if (e.key === '/' || e.key === 'ArrowRight')             { this.sim.setFlipper('right', true); }
            else if (e.key === ' ')                                        { e.preventDefault(); this._beginCharge(); }
            else if (e.key === 'x' || e.key === 'X')                       { this.hooks.cycleDimension?.(); }
            else return;
        };
        const onKeyUp = (e) => {
            if (!this.active) return;
            if (e.key === 'z' || e.key === 'Z' || e.key === 'ArrowLeft')  this.sim.setFlipper('left', false);
            else if (e.key === '/' || e.key === 'ArrowRight')             this.sim.setFlipper('right', false);
            else if (e.key === ' ')                                        this._releaseCharge();
        };
        const onPointerDown = (e) => {
            if (!this.active) return;
            this.target.setPointerCapture?.(e.pointerId);
            const rect = this.target.getBoundingClientRect();
            const fx = (e.clientX - rect.left) / Math.max(1, rect.width);
            const fy = (e.clientY - rect.top) / Math.max(1, rect.height);
            // Bottom-right corner = launch lane.
            if (fx > 0.78 && fy > 0.7) { this._beginCharge(); return; }
            const side = fx < 0.5 ? 'left' : 'right';
            this._pointerSide = side;
            this.sim.setFlipper(side, true);
        };
        const onPointerUp = () => {
            if (this._charging) this._releaseCharge();
            if (this._pointerSide) { this.sim.setFlipper(this._pointerSide, false); this._pointerSide = null; }
        };

        this._bound = { onKeyDown, onKeyUp, onPointerUp };
        document.addEventListener('keydown', onKeyDown);
        document.addEventListener('keyup', onKeyUp);
        this.target.addEventListener('pointerdown', onPointerDown);
        window.addEventListener('pointerup', onPointerUp);
        this._bound.onPointerDown = onPointerDown;
    }

    /** Advance the charge ramp; call once per frame. */
    update() {
        if (this._charging) {
            this._charge = Math.min(1, (performance.now() - this._chargeStart) / CHARGE_TIME_MS);
        }
    }

    _beginCharge() {
        const b = this.sim.balls[0];
        if (!b || b.launched) return;
        if (!this._charging) { this._charging = true; this._chargeStart = performance.now(); }
    }

    _releaseCharge() {
        if (!this._charging) return;
        this.sim.launch(this._charge);
        this._charging = false;
        this._charge = 0;
    }

    detach() {
        const b = this._bound;
        if (b.onKeyDown) document.removeEventListener('keydown', b.onKeyDown);
        if (b.onKeyUp)   document.removeEventListener('keyup', b.onKeyUp);
        if (b.onPointerDown) this.target?.removeEventListener('pointerdown', b.onPointerDown);
        if (b.onPointerUp)   window.removeEventListener('pointerup', b.onPointerUp);
        this._bound = {};
    }
}

/**
 * PinballEventBus — the game's nervous system.
 *
 * Per the TDD architecture: collision decides what happened → the event bus
 * decides what it means → rendering/scoring/audio make it visible. Producers
 * (the sim) emit facts; consumers (scoring, particles, audio, missions,
 * reactor, shaders) react.
 *
 * Pooling: this bus does NOT allocate per emit — producers own reusable scratch
 * payload objects and pass them in (see PinballSimWorld._cEvt). Consumers MUST
 * read the fields they need synchronously and MUST NOT retain the payload
 * reference, since the producer reuses it on the next emit.
 *
 * Optionally bridges to OS IPC so other apps/overlays can observe gameplay.
 */

export const PinballEvents = Object.freeze({
    COLLISION:      'PINBALL_COLLISION',     // { ballId, objectId, objectType, force, nx, ny, x, y, dimension }
    BALL_ENTER_ZONE:'BALL_ENTER_ZONE',       // { zoneId, ballId, dimension }
    BALL_EXIT_ZONE: 'BALL_EXIT_ZONE',        // { zoneId, ballId }
    BALL_DRAINED:   'BALL_DRAINED',          // { ballId, mode }
    BALL_LAUNCHED:  'BALL_LAUNCHED',         // { ballId, power }
    DIMENSION_SHIFT:'DIMENSION_SHIFT',       // { from, to, ballId, x, y }
    WAVE_PULSE:     'WAVE_PULSE_CREATED',    // { x, y, amplitude, wavelengthNm, sourceId }
    RESONANCE:      'RESONANCE_TRIGGERED',   // { sourceIds, multiplier, phaseError }
    CHARGE:         'CHARGE_CHANGED',        // { charge, dimension, plasma }
    PLASMA_SURGE:   'PLASMA_SURGE',          // { x, y, dimension, bonus }
    ORBIT:          'ORBIT_COMPLETED',       // { x, y, wellId, combo, bonus }
    REACTOR_STATE:  'REACTOR_STATE_CHANGED', // { oldState, newState, stability }
    MISSION:        'MISSION_CHANGED',        // { stageIndex, stageId, title, status, progress, target, bonus, wizardReady }
    SCORE:          'SCORE_CHANGED',         // { score, delta, comboTag }
    GAME_STATE:     'GAME_STATE_CHANGED',    // { state, balls }
});

export class PinballEventBus {
    constructor() {
        /** @type {Map<string, Set<Function>>} */
        this._listeners = new Map();
        this._ipc = null;     // optional syscalls.ipc bridge
        this._ipcTypes = null; // Set of event types mirrored to IPC
    }

    /**
     * Subscribe to an event type. Returns an unsubscribe function.
     * @param {string} type
     * @param {(payload:object)=>void} cb
     */
    on(type, cb) {
        let set = this._listeners.get(type);
        if (!set) { set = new Set(); this._listeners.set(type, set); }
        set.add(cb);
        return () => set.delete(cb);
    }

    off(type, cb) { this._listeners.get(type)?.delete(cb); }

    /**
     * Emit synchronously to all listeners. `payload` is caller-owned (typically a
     * reused scratch object) — listeners must not retain it.
     */
    emit(type, payload) {
        const set = this._listeners.get(type);
        if (set) {
            for (const cb of set) {
                try { cb(payload); }
                catch (e) { try { console.warn('[Pinball] listener error for ' + type, e); } catch {} }
            }
        }
        if (this._ipc && (!this._ipcTypes || this._ipcTypes.has(type))) {
            // Shallow copy for IPC since the scratch payload is reused immediately.
            try { this._ipc.emit('pinball:' + type, { ...payload }); } catch {}
        }
    }

    /**
     * Mirror selected event types to OS IPC so other apps/overlays can observe.
     * @param {object} ipc      syscalls.ipc
     * @param {string[]} [types] event types to mirror (default: a curated subset)
     */
    bridgeToIpc(ipc, types = null) {
        this._ipc = ipc ?? null;
        this._ipcTypes = types ? new Set(types) : new Set([
            PinballEvents.SCORE, PinballEvents.GAME_STATE,
            PinballEvents.DIMENSION_SHIFT, PinballEvents.REACTOR_STATE,
            PinballEvents.MISSION, PinballEvents.BALL_DRAINED,
        ]);
    }

    clear() { this._listeners.clear(); this._ipc = null; this._ipcTypes = null; }
}

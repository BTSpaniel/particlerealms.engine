/**
 * ResonanceSystem — timing layer (TDD §9).
 *
 * The reactor pulses on a steady oscillator (a "beat"). Striking a scoring
 * object *on-beat* (within a phase-match window of the oscillator peak) couples
 * energy into the system: it pays an escalating resonance bonus and emits
 * `RESONANCE_TRIGGERED`. Off-beat hits break the streak. Every scoring hit also
 * emits a `WAVE_PULSE_CREATED` ripple (consumed by FX now, spectral optics in
 * Phase 8).
 *
 * This is a consumer/producer layered on the sim: it observes `COLLISION` on the
 * bus and awards through `sim.addScore` (so the dimension + plasma multipliers
 * still stack). The app advances the oscillator each frame via `update(dt)`.
 */
import { PinballEvents } from './PinballEventBus.js';
import { getDimension } from './Dimensions.js';

const SCORING_TYPES = new Set(['bumper', 'target', 'slingshot']);

export class ResonanceSystem {
    /**
     * @param {import('./PinballSimWorld.js').PinballSimWorld} sim
     * @param {import('./PinballEventBus.js').PinballEventBus} bus
     * @param {object} [opts]
     */
    constructor(sim, bus, opts = {}) {
        this.sim = sim;
        this.bus = bus;
        this.freq = opts.freq ?? 1.4;       // beat frequency (Hz)
        this.window = opts.window ?? 0.16;  // phase-match tolerance (fraction of a cycle)
        this.phase = 0;                     // oscillator phase [0,1)
        this.combo = 0;                     // consecutive on-beat hits
        this._lastTrigger = 0;              // time of last resonance (for HUD flash)

        // Reusable scratch payloads — no per-hit allocation.
        this._wEvt = { x: 0, y: 0, amplitude: 0, wavelengthNm: 550, sourceId: '' };
        this._rEvt = { sourceIds: [''], multiplier: 1, phaseError: 0, bonus: 0, combo: 0, x: 0, y: 0 };

        this._unsub = bus.on(PinballEvents.COLLISION, (e) => this._onHit(e));
    }

    /** Advance the reactor oscillator. Call once per frame. */
    update(dt) {
        if (dt > 0) this.phase = (this.phase + this.freq * dt) % 1;
    }

    /** Closeness to the beat peak in [0..1] (1 = dead on the beat) — for the HUD. */
    get beat() {
        const pe = Math.min(this.phase, 1 - this.phase); // distance to nearest peak (phase 0/1)
        return Math.max(0, 1 - pe / this.window);
    }

    _onHit(e) {
        if (!SCORING_TYPES.has(e.objectType)) return;

        // Wave pulse ripple from the impact (amplitude scales with force).
        const band = getDimension(e.dimension).spectralBand;
        const w = this._wEvt;
        w.x = e.x; w.y = e.y; w.amplitude = Math.min(1, (e.force ?? 0) / 1200);
        w.wavelengthNm = (band[0] + band[1]) * 0.5; w.sourceId = e.objectId;
        this.bus.emit(PinballEvents.WAVE_PULSE, w);

        // Phase match: distance to the nearest oscillator peak.
        const pe = Math.min(this.phase, 1 - this.phase);
        if (pe <= this.window) {
            this.combo = Math.min(this.combo + 1, 8);
            const multiplier = 1 + this.combo;          // 2×..9×
            const bonus = 250 * this.combo;             // before dimension/plasma mult
            this.sim.addScore(bonus, 'resonance');
            this._lastTrigger = this.sim._now ?? 0;
            const r = this._rEvt;
            r.sourceIds[0] = e.objectId; r.multiplier = multiplier; r.phaseError = pe;
            r.bonus = bonus; r.combo = this.combo; r.x = e.x; r.y = e.y;
            this.bus.emit(PinballEvents.RESONANCE, r);
        } else {
            this.combo = 0;
        }
    }

    destroy() { this._unsub?.(); this._unsub = null; }
}

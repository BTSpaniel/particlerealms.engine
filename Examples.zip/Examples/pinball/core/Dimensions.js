/**
 * Dimensions.js — the five realities of The Reactor (TDD §4 / §17.1).
 *
 * Each dimension alters physics (gravity, friction, flipper power, bumper
 * impulse), scoring, particle density, and the spectral band that drives its
 * signature color. Phase 1 runs only `matter`; Phase 3's DimensionManager uses
 * this table to shift collision filters, forces, visuals, and UI together.
 *
 * `spectralBand` is the [minNm, maxNm] wavelength range fed to the spectral LUT
 * (Phase 8). `order` is the unlock/progression sequence.
 */

export const DIMENSIONS = Object.freeze({
    matter: {
        name: 'Matter', order: 0,
        gravityScale: 1.0, frictionScale: 1.0, flipperPower: 1.0, bumperImpulse: 1.0,
        scoreMultiplier: 1.0, particleDensity: 0.8, spectralBand: [580, 620],
        purpose: 'Survival and learning',
        palette: { primary: '#cfd8e6', accent: '#ffd27f', core: '#ffffff' },
    },
    particle: {
        name: 'Particle', order: 1,
        gravityScale: 0.85, frictionScale: 0.985, flipperPower: 1.05, bumperImpulse: 1.15,
        scoreMultiplier: 1.5, particleDensity: 2.5, spectralBand: [470, 510],
        purpose: 'Charging and flow',
        palette: { primary: '#39d7ff', accent: '#1fd2b4', core: '#a9f4ff' },
    },
    gravity: {
        name: 'Gravity', order: 2,
        gravityScale: 0.65, frictionScale: 0.995, flipperPower: 0.95, bumperImpulse: 0.9,
        scoreMultiplier: 2.0, particleDensity: 2.0, spectralBand: [430, 470],
        purpose: 'Combos and curved skill shots',
        palette: { primary: '#7a6bff', accent: '#3a4bd0', core: '#c2b8ff' },
    },
    shadow: {
        name: 'Shadow', order: 3,
        gravityScale: 0.95, frictionScale: 0.99, flipperPower: 1.0, bumperImpulse: 1.0,
        scoreMultiplier: 2.5, particleDensity: 1.4, spectralBand: [410, 455],
        purpose: 'Risk, secrets, phasing',
        palette: { primary: '#5a4a78', accent: '#c43a3a', core: '#1a1020' },
    },
    chaos: {
        name: 'Chaos', order: 4,
        gravityScale: 0.8, frictionScale: 0.992, flipperPower: 1.1, bumperImpulse: 1.2,
        scoreMultiplier: 5.0, particleDensity: 4.0, spectralBand: [380, 780],
        purpose: 'Endgame overload',
        palette: { primary: '#ffffff', accent: '#ff5ed0', core: '#fff3b0' },
    },
});

/** Dimension ids in unlock order. */
export const DIMENSION_ORDER = Object.freeze(['matter', 'particle', 'gravity', 'shadow', 'chaos']);

/** Safe lookup with a Matter fallback. */
export function getDimension(id) {
    return DIMENSIONS[id] ?? DIMENSIONS.matter;
}

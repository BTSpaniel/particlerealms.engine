/**
 * ReactorSystem — the table's central energy state machine (TDD §10).
 *
 * Scoring pumps reactor energy (the `reactor_core` standup pumps it hard); energy
 * climbs the chain Stable → Charged → Unstable → Critical → Meltdown. Reaching
 * Critical arms the core: the next core shot (or hitting full energy) triggers a
 * MELTDOWN — a jackpot payout (a GRAND reactor jackpot when the mission chain has
 * armed the wizard mode) — then the reactor cools back to Charged.
 *
 * Energy bleeds slowly so it must be actively worked up. State transitions emit
 * `REACTOR_STATE_CHANGED` (the renderer brightens the volumetric core, the HUD
 * recolors, audio reacts). Awards go through `sim.addScore` so the dimension +
 * plasma + resonance multipliers all stack.
 */
import { PinballEvents } from './PinballEventBus.js';
import { SCORE } from './PinballSimWorld.js';

// Ordered states with the energy threshold at which each begins.
const STATES = [
    { id: 'stable',   at: 0.00 },
    { id: 'charged',  at: 0.30 },
    { id: 'unstable', at: 0.55 },
    { id: 'critical', at: 0.80 },
];

const GAIN = {
    core: 0.24,        // reactor_core standup — the big pump
    bumper: 0.015,
    target: 0.03,
    slingshot: 0.006,
    resonance: 0.045,
    orbit: 0.06,
    plasma: 0.12,
};

export class ReactorSystem {
    constructor(sim, bus) {
        this.sim = sim;
        this.bus = bus;
        this.energy = 0;          // [0..1]
        this.state = 'stable';
        this.grandArmed = false;  // set by MissionSystem when the wizard mode is ready
        this._meltdownUntil = 0;  // cooldown so meltdown can't re-trigger instantly
        this._evt = { oldState: 'stable', newState: 'stable', stability: 0 };

        this._subs = [
            bus.on(PinballEvents.COLLISION, (e) => this._onHit(e)),
            bus.on(PinballEvents.RESONANCE, () => this._pump(GAIN.resonance)),
            bus.on(PinballEvents.ORBIT, () => this._pump(GAIN.orbit)),
            bus.on(PinballEvents.PLASMA_SURGE, () => this._pump(GAIN.plasma)),
        ];
    }

    /** Slow energy bleed; recompute state band each frame. */
    update(dt) {
        if (dt <= 0) return;
        if (this.energy > 0 && (this.sim._now ?? 0) > this._meltdownUntil) {
            this.energy = Math.max(0, this.energy - 0.03 * dt);
        }
        this._reconcileState();
    }

    /** MissionSystem calls this when all stages are done — next meltdown is GRAND. */
    armGrand() { this.grandArmed = true; }

    _onHit(e) {
        if (e.objectId === 'reactor_core') {
            this._pump(GAIN.core);
            // A core shot while Critical detonates the reactor.
            if (this.state === 'critical') this._meltdown(e.x, e.y);
            return;
        }
        const g = GAIN[e.objectType];
        if (g) this._pump(g);
    }

    _pump(amount) {
        const now = this.sim._now ?? 0;
        if (now < this._meltdownUntil) return; // cooling down
        this.energy = Math.min(1, this.energy + amount);
        if (this.energy >= 1) this._meltdown(this.sim.balls?.[0]?.x ?? 180, this.sim.balls?.[0]?.y ?? 200);
        else this._reconcileState();
    }

    _reconcileState() {
        let band = STATES[0].id;
        for (const s of STATES) if (this.energy >= s.at) band = s.id;
        if (band !== this.state) this._transition(band);
    }

    _transition(newState) {
        const old = this.state;
        this.state = newState;
        const ev = this._evt;
        ev.oldState = old; ev.newState = newState; ev.stability = this.energy;
        this.bus.emit(PinballEvents.REACTOR_STATE, ev);
    }

    _meltdown(x, y) {
        this._transition('meltdown');
        const bonus = this.grandArmed ? SCORE.reactorJackpot : SCORE.jackpot;
        this.sim.addScore(bonus, this.grandArmed ? 'reactor_grand' : 'reactor_jackpot');
        // Meltdown erupts into chaos multiball (TDD §11) — a grand meltdown packs
        // the table fully, a normal one adds a second ball.
        this.sim.startMultiball?.(this.grandArmed ? 4 : 2);
        this.grandArmed = false;
        this._meltdownUntil = (this.sim._now ?? 0) + 1.5; // brief cooldown
        this.energy = 0.32; // cool back toward Charged
    }

    destroy() { for (const u of this._subs) u?.(); this._subs = []; }
}

/**
 * DimensionManager — owns the active reality and performs atomic dimension
 * shifts (TDD §4/§5). A shift is the game's central mechanic: it must update
 * EVERYTHING together — physics params (the sim reads `DIMENSIONS[active]`),
 * collision membership (colliders tagged with `dims` are filtered by the sim),
 * visuals (the renderer reads `state.dimension` for palette + ghost previews),
 * audio, and UI — driven by a single `DIMENSION_SHIFT` event on the bus.
 *
 * Unlocks gate which realities are reachable; progression phases expand the set.
 */
import { PinballEvents } from './PinballEventBus.js';
import { DIMENSIONS, DIMENSION_ORDER, getDimension } from './Dimensions.js';

export class DimensionManager {
    /**
     * @param {import('./PinballSimWorld.js').PinballSimWorld} sim
     * @param {import('./PinballEventBus.js').PinballEventBus} bus
     * @param {object} [opts]
     * @param {string[]} [opts.unlocked] — initially reachable dimensions
     */
    constructor(sim, bus, opts = {}) {
        this.sim = sim;
        this.bus = bus;
        // Phase 3 default: Matter + the two dimensions with defined Phase 3–4
        // behavior. Shadow/Chaos unlock in their own phases via `unlock()`.
        this.unlocked = new Set(opts.unlocked ?? ['matter', 'particle', 'gravity', 'shadow']);
        this.active = 'matter';
        this.sim.dimension = 'matter';
    }

    unlock(id) { if (DIMENSIONS[id]) this.unlocked.add(id); }
    isUnlocked(id) { return this.unlocked.has(id); }

    /** Active dimension parameter block (gravity/flipper/score/palette/…). */
    get params() { return getDimension(this.active); }

    /** Unlocked dimensions in canonical order. */
    list() { return DIMENSION_ORDER.filter(d => this.unlocked.has(d)); }

    /**
     * Shift to `id` atomically. Updates sim physics tag + emits DIMENSION_SHIFT
     * (renderer/audio/HUD/missions all react to that single event).
     * @returns {boolean} true if the shift happened.
     */
    shiftTo(id, ctx = {}) {
        if (!DIMENSIONS[id] || id === this.active || !this.unlocked.has(id)) return false;
        const from = this.active;
        this.active = id;
        this.sim.dimension = id; // physics params + collision filter follow immediately
        this.bus.emit(PinballEvents.DIMENSION_SHIFT, {
            from, to: id,
            x: ctx.x ?? 0, y: ctx.y ?? 0, ballId: ctx.ballId ?? 0,
        });
        return true;
    }

    /** Cycle to the next unlocked dimension (manual control / debug / portals). */
    cycle(ctx = {}) {
        const l = this.list();
        if (l.length < 2) return false;
        const i = l.indexOf(this.active);
        return this.shiftTo(l[(i + 1) % l.length], ctx);
    }
}

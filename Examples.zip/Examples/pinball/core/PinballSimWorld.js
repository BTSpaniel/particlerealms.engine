/**
 * PinballSimWorld — authoritative 2.5D pinball simulation (Matter mode in Phase 1).
 *
 * The sim is the source of truth (TDD architecture). It owns the ball, flippers,
 * bumpers, slingshots, walls, launch lane, and drain, integrates them with an
 * adaptive sub-stepped solver (movement per step is capped below the ball radius
 * so fast shots cannot tunnel — the TDD's collision acceptance test), and emits
 * facts on the PinballEventBus. Rendering, scoring, particles, audio, missions,
 * resonance, and the reactor are all downstream consumers.
 *
 * Coordinate space: logical playfield x∈[0,PW], y∈[0,PH] with +y pointing DOWN
 * the inclined table (toward the flippers/drain). The renderer maps this to the
 * GPU surface; later phases lift it into the 3D table.
 *
 * The impulse model uses the contact-point relative normal velocity, so a moving
 * flipper naturally imparts energy (its surface velocity is part of the relative
 * velocity) — giving responsive, "live" flippers without special-casing.
 */
import { PinballEvents } from './PinballEventBus.js';
import { DIMENSIONS } from './Dimensions.js';

export const PW = 360;   // logical playfield width
export const PH = 620;   // logical playfield height
const BALL_R = 9;
export const MAX_BALLS = 4; // chaos-multiball hard cap (density management, TDD §11/§13)
const GRAVITY = 1500;    // px/s² along +y (table tilt)
const LINEAR_DAMP = 0.018; // per-second velocity bleed (rolling friction-ish)
const MAX_SPEED = 4200;  // clamp to keep the solver stable

// TDD §17.2 scoring constants.
export const SCORE = Object.freeze({
    bumperHit: 100, targetHit: 500, rampShot: 1000, orbitShot: 1500,
    comboShot: 2500, skillShot: 5000, lockShot: 7500, jackpot: 25000,
    reactorJackpot: 100000,
});

const LANE_X = PW - 26;   // launch-lane channel (right side)

export class PinballSimWorld {
    /**
     * @param {import('./PinballEventBus.js').PinballEventBus} eventBus
     * @param {object} [opts]
     */
    constructor(eventBus, opts = {}) {
        this.bus = eventBus;
        this.dimension = 'matter';
        this.balls = [];
        this.segments = [];   // { x1,y1,x2,y2, e, thick, id, type, kick }
        this.circles  = [];   // { x,y,r, e, id, type, kick, score, litUntil }
        this.flippers = [];   // { side, px,py, len, r, rest, active, angle, prevAngle, angVel, down, e }
        this.zones    = [];   // { id, x,y,w,h, dimension, _inside:Set }

        this.score = 0;
        this.ballsLeft = opts.balls ?? 3;
        this.state = 'ready'; // ready | launching | playing | lost
        this._nextBallId = 1;
        this._now = 0;

        // Particle-dimension charge mechanic: hits build charge (energy rails
        // charge fastest), and full charge fires a scoring plasma surge that opens
        // a short window where bumpers/targets pay a multiple (TDD §4 "Particle").
        this.charge = 0;            // [0..1], only builds in the particle dimension
        this._plasmaUntil = 0;      // surge window end time (s)
        this._chargeDirty = false;
        this._shadowPhase = 0;      // 0/1 — which shadow wall group is solid right now

        // Adaptive-difficulty actuator state (Phase 12). The AdaptiveAI modulates
        // these multipliers to keep the player in a target challenge band; defaults
        // are neutral so the sim behaves identically until the AI engages.
        this.difficulty = { kick: 1, gravity: 1, flipper: 1, saveSec: 0 };
        this._ballInPlaySince = 0;   // time the live ball was last launched (ball-save window)
        this._saveUsed = false;      // one ball-save per ball-in-play

        // Reusable scratch payloads — no per-collision allocation (TDD perf).
        this._cEvt = { type: PinballEvents.COLLISION, ballId: 0, objectId: '', objectType: '', force: 0, nx: 0, ny: 0, x: 0, y: 0, dimension: 'matter' };
        this._zEvt = { type: PinballEvents.BALL_ENTER_ZONE, zoneId: '', ballId: 0, dimension: 'matter' };
        this._chEvt = { charge: 0, dimension: 'matter', plasma: false };
        this._psEvt = { x: 0, y: 0, dimension: 'particle', bonus: 0 };
        this._oEvt  = { x: 0, y: 0, wellId: '', combo: 0, bonus: 0 };

        this._buildReactorTable();
        this.reset();
    }

    // ── Public control ────────────────────────────────────────────────────────

    reset() {
        this.balls.length = 0;
        this._spawnBall();
        this.state = 'ready';
        this._emitState();
    }

    /** Begin a new game (balls refilled). */
    newGame() {
        this.score = 0;
        this.ballsLeft = 3;
        this._emitScore(0, null);
        this.reset();
    }

    setFlipper(side, down) {
        for (const f of this.flippers) if (f.side === side) f.down = !!down;
    }

    /** Release the plunger with [0..1] power; launches the staged ball up the lane. */
    launch(power) {
        const b = this.balls[0];
        if (!b || b.launched) return;
        if (this.state === 'ready') this.state = 'playing';
        const p = Math.max(0, Math.min(1, power));
        b.vy = -(620 + p * 1180);
        b.vx = -30;
        b.launched = true;
        this._ballInPlaySince = this._now;
        this._saveUsed = false;
        this.bus.emit(PinballEvents.BALL_LAUNCHED, { ballId: b.id, power: p });
        this._emitState();
    }

    /** Read-only snapshot for the renderer / HUD. */
    getState() {
        return {
            balls: this.balls, flippers: this.flippers, circles: this.circles,
            segments: this.segments, zones: this.zones, score: this.score,
            ballsLeft: this.ballsLeft, state: this.state, dimension: this.dimension,
            charge: this.charge, plasma: this._now < this._plasmaUntil,
            shadowPhase: this._shadowPhase,
            now: this._now, PW, PH, ballR: BALL_R,
        };
    }

    // ── Simulation step ─────────────────────────────────────────────────────────

    step(dt) {
        if (!Number.isFinite(dt) || dt <= 0) return;
        dt = Math.min(dt, 0.05);
        this._now += dt;
        this._shadowPhase = Math.floor(this._now / 2.4) % 2; // shadow walls phase every 2.4s

        const dim = DIMENSIONS[this.dimension] ?? DIMENSIONS.matter;
        if (this.balls.length === 0) return;

        // Sub-step count is driven by the FASTEST ball so no ball tunnels in
        // multiball; all balls integrate together inside each sub-step.
        const maxMove = BALL_R * 0.4;
        let maxSpeed = 0, anyLaunched = false;
        for (const bb of this.balls) {
            if (!bb.launched) continue;
            anyLaunched = true;
            const s = Math.hypot(bb.vx, bb.vy);
            if (s > maxSpeed) maxSpeed = s;
        }
        const nSub = anyLaunched
            ? Math.max(1, Math.min(40, Math.ceil((maxSpeed * dt) / maxMove)))
            : 1;
        const h = dt / nSub;

        for (let s = 0; s < nSub; s++) {
            this._stepFlippers(h);                 // flippers animate regardless
            for (const bb of this.balls) {
                if (!bb.launched) continue;

                // Integrate (gravity scaled by active dimension).
                bb.vy += GRAVITY * dim.gravityScale * this.difficulty.gravity * h;
                if (this.dimension === 'gravity') this._applyWells(bb, h);
                const damp = Math.max(0, 1 - LINEAR_DAMP * h);
                bb.vx *= damp; bb.vy *= damp;
                const sp = Math.hypot(bb.vx, bb.vy);
                if (sp > MAX_SPEED) { const k = MAX_SPEED / sp; bb.vx *= k; bb.vy *= k; }

                bb.x += bb.vx * h;
                bb.y += bb.vy * h;

                this._collideCircles(bb, dim);
                this._collideSegments(bb, dim);
                this._collideFlippers(bb, dim);
                this._collideLaneWalls(bb);
            }
        }

        for (const bb of this.balls) this._checkZones(bb);
        // Orbit tracking uses shared per-well state, so follow the primary ball only.
        if (this.dimension === 'gravity' && this.balls[0]) this._trackOrbits(this.balls[0]);

        // Charge bleeds away over time — slowly while in the particle dimension
        // (where it's the core mechanic), fast otherwise so it can't be hoarded.
        if (this.charge > 0) {
            const rate = this.dimension === 'particle' ? 0.045 : 0.3;
            const prev = this.charge;
            this.charge = Math.max(0, this.charge - rate * dt);
            if (this.charge !== prev) this._chargeDirty = true;
        }
        if (this._chargeDirty) { this._emitCharge(); this._chargeDirty = false; }

        // Drain: any ball that fell past the flipper line through the centre gap.
        // Iterate backwards since `_drain` splices from the array.
        for (let i = this.balls.length - 1; i >= 0; i--) {
            const bb = this.balls[i];
            if (bb.y - BALL_R > PH + 8) this._drain(bb);
        }
    }

    /**
     * Chaos multiball (TDD §11): top the table up to `count` balls (hard-capped),
     * launched outward from the reactor core. Only fires during active play; extra
     * balls draining don't cost a life (see `_drain`) — losing the last one does.
     * Returns how many balls were spawned.
     */
    startMultiball(count = 3) {
        if (this.state !== 'playing') return 0;
        const cap = Math.min(count, MAX_BALLS);
        let spawned = 0;
        while (this.balls.length < cap) {
            this.balls.push({
                id: this._nextBallId++,
                x: PW / 2 + (Math.random() - 0.5) * 40, y: 236,
                vx: (Math.random() - 0.5) * 320, vy: -(420 + Math.random() * 320),
                r: BALL_R, launched: true,
            });
            spawned++;
        }
        if (spawned) this._emitState();
        return spawned;
    }

    // ── Particle-dimension charge / plasma surge ─────────────────────────────────

    /** Build charge from a hit (particle dimension only). May fire a plasma surge. */
    _addCharge(amount, x, y) {
        if (this.dimension !== 'particle' || amount <= 0) return;
        this.charge = Math.min(1, this.charge + amount);
        this._chargeDirty = true;
        if (this.charge >= 1) this._triggerPlasma(x, y);
    }

    _triggerPlasma(x, y) {
        this.charge = 0;
        this._plasmaUntil = this._now + 6;   // 6s window where bumpers/targets pay 3×
        const bonus = Math.round(SCORE.jackpot * 0.5 * (DIMENSIONS.particle.scoreMultiplier));
        this.score += bonus;
        this._emitScore(bonus, 'plasma');
        const ev = this._psEvt;
        ev.x = x; ev.y = y; ev.dimension = 'particle'; ev.bonus = bonus;
        this.bus.emit(PinballEvents.PLASMA_SURGE, ev);
    }

    _emitCharge() {
        const ev = this._chEvt;
        ev.charge = this.charge; ev.dimension = this.dimension; ev.plasma = this._now < this._plasmaUntil;
        this.bus.emit(PinballEvents.CHARGE, ev);
    }

    // ── Gravity-dimension wells & orbits ─────────────────────────────────────────

    /** Inverse-square-ish attraction toward each well (bends shots into orbits). */
    _applyWells(b, h) {
        const G = 1.0e7;       // attraction constant (tuned for px-space orbits)
        const INFLU = 165;     // influence radius (px)
        for (const w of this.wells) {
            const dx = w.x - b.x, dy = w.y - b.y;
            const d2 = dx * dx + dy * dy;
            const d = Math.sqrt(d2) || 1e-3;
            if (d > INFLU) continue;
            // Softened core (+400) avoids a singularity; clamp keeps the solver sane.
            const a = Math.min((G * w.wellStrength) / (d2 + 400), 6000);
            b.vx += (dx / d) * a * h;
            b.vy += (dy / d) * a * h;
        }
    }

    /**
     * Track the signed angle the ball sweeps around each well while in the orbit
     * band; a full revolution pays an escalating orbit bonus and resets.
     */
    _trackOrbits(b) {
        const BAND_MIN = 20, BAND_MAX = 140;
        for (const w of this.wells) {
            const dx = b.x - w.x, dy = b.y - w.y;
            const d = Math.hypot(dx, dy);
            const ang = Math.atan2(dy, dx);
            if (d < BAND_MIN || d > BAND_MAX) {
                w._orbActive = false; w._orbAccum = 0; w._orbCount = 0; w._orbAngle = ang;
                continue;
            }
            if (!w._orbActive) { w._orbActive = true; w._orbAccum = 0; w._orbAngle = ang; continue; }
            let dA = ang - w._orbAngle;
            if (dA > Math.PI) dA -= 2 * Math.PI; else if (dA < -Math.PI) dA += 2 * Math.PI;
            w._orbAccum += dA;
            w._orbAngle = ang;
            if (Math.abs(w._orbAccum) >= 2 * Math.PI) {
                w._orbAccum = 0;
                this._awardOrbit(w);
            }
        }
    }

    /** Shadow ball-lock scoop: capture for a bonus, then eject the ball up-table. */
    _shadowLock(b, z) {
        this.addScore(SCORE.lockShot, 'lock');
        b.vy = -1000; b.vx = (Math.random() - 0.5) * 140;
        this._emitCollision(b, z.id, 'lock', 9, 0, -1); // spark FX at the scoop
    }

    _awardOrbit(w) {
        w._orbCount = Math.min((w._orbCount || 0) + 1, 5);
        const bonus = SCORE.orbitShot * w._orbCount; // dimension multiplier applied in addScore
        this.addScore(bonus, 'orbit');
        w.litUntil = this._now + 0.3;
        const ev = this._oEvt;
        ev.x = w.x; ev.y = w.y; ev.wellId = w.id; ev.combo = w._orbCount; ev.bonus = bonus;
        this.bus.emit(PinballEvents.ORBIT, ev);
    }

    // ── Collision resolvers ──────────────────────────────────────────────────────

    _collideCircles(b, dim) {
        for (const c of this.circles) {
            if (c.dims && !c.dims.includes(this.dimension)) continue; // dimension membership filter
            if (c.phaseGroup !== undefined && this._shadowPhase !== c.phaseGroup) continue; // phased out
            const dx = b.x - c.x, dy = b.y - c.y;
            const rr = BALL_R + c.r;
            const d2 = dx * dx + dy * dy;
            if (d2 >= rr * rr) continue;
            const d = Math.sqrt(d2) || 1e-4;
            const nx = dx / d, ny = dy / d;
            b.x = c.x + nx * (rr + 0.1);
            b.y = c.y + ny * (rr + 0.1);
            const vn = b.vx * nx + b.vy * ny;
            if (vn < 0) {
                const j = -(1 + c.e) * vn;
                b.vx += j * nx; b.vy += j * ny;
            }
            if (c.kick) {
                const kick = c.kick * (c.type === 'bumper' ? dim.bumperImpulse : 1) * this.difficulty.kick;
                b.vx += nx * kick; b.vy += ny * kick;
            }
            c.litUntil = this._now + 0.18;
            this._emitCollision(b, c.id, c.type, Math.abs(vn), nx, ny);
        }
    }

    _collideSegments(b, dim) {
        for (const sg of this.segments) {
            if (sg.dims && !sg.dims.includes(this.dimension)) continue; // dimension membership filter
            if (sg.phaseGroup !== undefined && this._shadowPhase !== sg.phaseGroup) continue; // phased out (intangible)
            const hit = this._resolveSegment(b, sg.x1, sg.y1, sg.x2, sg.y2, sg.thick, sg.e, 0, 0);
            if (hit) {
                if (sg.kick) { const k = sg.kick * dim.bumperImpulse * this.difficulty.kick; b.vx += hit.nx * k; b.vy += hit.ny * k; }
                this._emitCollision(b, sg.id, sg.type, hit.force, hit.nx, hit.ny);
            }
        }
    }

    _collideFlippers(b, dim) {
        for (const f of this.flippers) {
            const tx = f.px + Math.cos(f.angle) * f.len;
            const ty = f.py + Math.sin(f.angle) * f.len;
            // Contact-point surface velocity from angular velocity (ω × r).
            const hit = this._resolveSegment(b, f.px, f.py, tx, ty, f.r, f.e, f.angVel, f);
            if (hit) {
                // Flipper power boost when actively flipping up into the ball.
                if (f.down && hit.movingIn) {
                    const boost = 70 * dim.flipperPower * this.difficulty.flipper;
                    b.vx += hit.nx * boost; b.vy += hit.ny * boost;
                }
                this._emitCollision(b, 'flipper_' + f.side, 'flipper', hit.force, hit.nx, hit.ny);
            }
        }
    }

    /**
     * Resolve ball vs a thick segment (capsule). If `angVel` is given with flipper
     * `f`, the contact-point velocity (ω × r) is folded into the relative normal
     * velocity so a moving flipper transfers energy. Returns hit info or null.
     */
    _resolveSegment(b, x1, y1, x2, y2, thick, e, angVel = 0, f = null) {
        const abx = x2 - x1, aby = y2 - y1;
        const abLen2 = abx * abx + aby * aby || 1e-6;
        let t = ((b.x - x1) * abx + (b.y - y1) * aby) / abLen2;
        t = t < 0 ? 0 : t > 1 ? 1 : t;
        const cx = x1 + t * abx, cy = y1 + t * aby;
        const dx = b.x - cx, dy = b.y - cy;
        const rr = BALL_R + thick;
        const d2 = dx * dx + dy * dy;
        if (d2 >= rr * rr) return null;
        const d = Math.sqrt(d2) || 1e-4;
        const nx = dx / d, ny = dy / d;
        b.x = cx + nx * (rr + 0.1);
        b.y = cy + ny * (rr + 0.1);

        // Contact-point velocity of the (rotating) collider.
        let vptx = 0, vpty = 0;
        if (f && angVel) { const rx = cx - f.px, ry = cy - f.py; vptx = -angVel * ry; vpty = angVel * rx; }

        const rvx = b.vx - vptx, rvy = b.vy - vpty;
        const vn = rvx * nx + rvy * ny;
        let force = 0;
        const movingIn = vn < 0;
        if (movingIn) {
            const j = -(1 + e) * vn;
            b.vx += j * nx; b.vy += j * ny;
            force = Math.abs(vn);
        }
        return { nx, ny, force, movingIn };
    }

    /** Keep the ball inside the cabinet's left/right/top + the launch-lane channel. */
    _collideLaneWalls(b) {
        if (b.x - BALL_R < 6) { b.x = 6 + BALL_R; if (b.vx < 0) b.vx = -b.vx * 0.5; }
        if (b.x + BALL_R > PW - 6) { b.x = PW - 6 - BALL_R; if (b.vx > 0) b.vx = -b.vx * 0.5; }
        if (b.y - BALL_R < 6) { b.y = 6 + BALL_R; if (b.vy < 0) b.vy = -b.vy * 0.5; }
        // While unlaunched, hold the ball in the right lane channel.
        if (!b.launched && b.x < LANE_X) { b.x = LANE_X; b.vx = 0; }
    }

    _checkZones(b) {
        for (const z of this.zones) {
            const inside = b.x > z.x && b.x < z.x + z.w && b.y > z.y && b.y < z.y + z.h;
            const was = z._inside.has(b.id);
            if (inside && !was) {
                z._inside.add(b.id);
                this._zEvt.zoneId = z.id; this._zEvt.ballId = b.id; this._zEvt.dimension = this.dimension;
                this.bus.emit(PinballEvents.BALL_ENTER_ZONE, this._zEvt);
                if (z.lock && this.dimension === 'shadow') this._shadowLock(b, z);
            } else if (!inside && was) {
                z._inside.delete(b.id);
            }
        }
    }

    _stepFlippers(h) {
        for (const f of this.flippers) {
            const target = f.down ? f.active : f.rest;
            f.prevAngle = f.angle;
            // Critically-fast spring toward target (snappy but stable).
            const k = Math.min(1, h * 26);
            f.angle += (target - f.angle) * k;
            f.angVel = (f.angle - f.prevAngle) / h;
        }
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────────

    _spawnBall() {
        const b = { id: this._nextBallId++, x: LANE_X, y: PH - 70, vx: 0, vy: 0, r: BALL_R, launched: false };
        this.balls.push(b);
        return b;
    }

    _drain(b) {
        const i = this.balls.indexOf(b);
        if (i >= 0) this.balls.splice(i, 1);
        this.bus.emit(PinballEvents.BALL_DRAINED, { ballId: b.id, mode: this.dimension });
        if (this.balls.length > 0) return; // multiball still in play
        // Ball save (adaptive): a fast early drain serves a fresh ball without
        // costing a life. The actuator widens this window for struggling players.
        if (this.difficulty.saveSec > 0 && !this._saveUsed && this.ballsLeft > 0 &&
            (this._now - this._ballInPlaySince) < this.difficulty.saveSec) {
            this._saveUsed = true;
            this._spawnBall();
            this.state = 'ready';
            this._emitState();
            return;
        }
        this.ballsLeft--;
        if (this.ballsLeft <= 0) {
            this.state = 'lost';
            this._emitState();
        } else {
            this._spawnBall();
            this.state = 'ready';
            this._emitState();
        }
    }

    /** Adaptive-difficulty actuator entry point (called by AdaptiveAI). */
    setDifficulty(d) {
        if (!d) return;
        const clamp = (v, lo, hi, def) => (Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : def);
        this.difficulty.kick    = clamp(d.kick,    0.7, 1.4, 1);
        this.difficulty.gravity = clamp(d.gravity, 0.8, 1.3, 1);
        this.difficulty.flipper = clamp(d.flipper, 0.8, 1.4, 1);
        this.difficulty.saveSec = clamp(d.saveSec, 0,   6,   0);
    }

    // ── Event helpers ─────────────────────────────────────────────────────────────

    _emitCollision(b, objectId, objectType, force, nx, ny) {
        const ev = this._cEvt;
        ev.ballId = b.id; ev.objectId = objectId; ev.objectType = objectType;
        ev.force = force; ev.nx = nx; ev.ny = ny; ev.x = b.x; ev.y = b.y; ev.dimension = this.dimension;
        this.bus.emit(PinballEvents.COLLISION, ev);

        // Phase 1 base scoring (dimension multiplier applied).
        let pts = 0;
        if (objectType === 'bumper') pts = SCORE.bumperHit;
        else if (objectType === 'target') pts = SCORE.targetHit;
        else if (objectType === 'slingshot') pts = 10;
        if (pts) this.addScore(pts, objectType);

        // Particle dimension: hits build charge. Energy rails charge fastest,
        // then targets, bumpers; slingshots barely tickle it.
        let chg = 0;
        if (objectId === 'particle_rail') chg = 0.26;
        else if (objectType === 'target')  chg = 0.16;
        else if (objectType === 'bumper')   chg = 0.11;
        else if (objectType === 'slingshot') chg = 0.04;
        if (chg) this._addCharge(chg, b.x, b.y);
    }

    addScore(base, comboTag) {
        const mult = (DIMENSIONS[this.dimension] ?? DIMENSIONS.matter).scoreMultiplier;
        // Plasma surge window pays a 3× bonus on top of the dimension multiplier.
        const plasma = this._now < this._plasmaUntil ? 3 : 1;
        const delta = Math.round(base * mult * plasma);
        this.score += delta;
        this._emitScore(delta, comboTag);
    }

    _emitScore(delta, comboTag) {
        this.bus.emit(PinballEvents.SCORE, { score: this.score, delta, comboTag });
    }

    _emitState() {
        this.bus.emit(PinballEvents.GAME_STATE, { state: this.state, balls: this.ballsLeft });
    }

    // ── Table geometry — Table 01: The Reactor (Matter layout) ────────────────────

    _buildReactorTable() {
        const seg = (x1, y1, x2, y2, opts = {}) => this.segments.push({
            x1, y1, x2, y2, thick: opts.thick ?? 3, e: opts.e ?? 0.32,
            id: opts.id ?? 'wall', type: opts.type ?? 'wall', kick: opts.kick ?? 0,
        });
        // Rounded corner: emit `n` short chord segments along an arc so the ball
        // deflects smoothly around it instead of catching in a sharp 90° pocket.
        const arc = (cx, cy, r, a0, a1, n = 7, opts = {}) => {
            let px = cx + r * Math.cos(a0), py = cy + r * Math.sin(a0);
            for (let i = 1; i <= n; i++) {
                const a = a0 + (a1 - a0) * (i / n);
                const nx = cx + r * Math.cos(a), ny = cy + r * Math.sin(a);
                seg(px, py, nx, ny, opts);
                px = nx; py = ny;
            }
        };

        // Outer cabinet with rounded top corners (leaving a drain gap at the bottom).
        const R = 46;           // corner fillet radius
        const D = Math.PI / 180;
        seg(6 + R, 6, PW - 6 - R, 6, { id: 'wall_top' });
        arc(6 + R, 6 + R, R, 180 * D, 270 * D, 7, { id: 'corner_tl' });        // left → top
        arc(PW - 6 - R, 6 + R, R, 270 * D, 360 * D, 7, { id: 'corner_tr' });    // top → right
        seg(6, 6 + R, 6, PH - 150, { id: 'wall_left' });
        seg(PW - 6, 6 + R, PW - 6, PH - 90, { id: 'wall_right' });
        // Launch-lane divider (right channel).
        seg(LANE_X - 12, 120, LANE_X - 12, PH - 90, { id: 'lane_wall' });
        // Lower inward-angled guides funnelling toward the flippers.
        seg(6, PH - 150, 120, PH - 70, { id: 'guide_left', e: 0.28 });
        seg(LANE_X - 12, PH - 90, PW - 120 - 26, PH - 70, { id: 'guide_right', e: 0.28 });

        // Slingshots (angled kickers above each flipper).
        seg(70, PH - 150, 120, PH - 96, { id: 'sling_left', type: 'slingshot', e: 0.5, kick: 240, thick: 4 });
        seg(LANE_X - 70, PH - 150, LANE_X - 120, PH - 96, { id: 'sling_right', type: 'slingshot', e: 0.5, kick: 240, thick: 4 });

        // Pop bumpers — a five-bumper cluster in the upper playfield.
        this.circles.push({ x: 120, y: 175, r: 22, e: 0.55, kick: 300, id: 'bumper_1', type: 'bumper', score: SCORE.bumperHit, litUntil: 0 });
        this.circles.push({ x: 232, y: 205, r: 20, e: 0.55, kick: 300, id: 'bumper_2', type: 'bumper', score: SCORE.bumperHit, litUntil: 0 });
        this.circles.push({ x: 168, y: 268, r: 18, e: 0.55, kick: 300, id: 'bumper_3', type: 'bumper', score: SCORE.bumperHit, litUntil: 0 });
        this.circles.push({ x: 74,  y: 236, r: 15, e: 0.55, kick: 290, id: 'bumper_4', type: 'bumper', score: SCORE.bumperHit, litUntil: 0 });
        this.circles.push({ x: 280, y: 268, r: 15, e: 0.55, kick: 290, id: 'bumper_5', type: 'bumper', score: SCORE.bumperHit, litUntil: 0 });

        // Reactor core (THE core shot): the standup at table centre, aligned with the
        // volumetric reactor orb. Hitting it pumps the reactor hard (ReactorSystem).
        // Universal across all dimensions.
        this.circles.push({ x: 180, y: 200, r: 13, e: 0.5, kick: 150, id: 'reactor_core', type: 'target', score: SCORE.rampShot, litUntil: 0 });

        // Reactor-target posts + a left standup drop-bank (mission + reactor fodder).
        this.circles.push({ x: 90,  y: 320, r: 8, e: 0.4, kick: 120, id: 'reactor_target_1', type: 'target', score: SCORE.targetHit, litUntil: 0 });
        this.circles.push({ x: 270, y: 320, r: 8, e: 0.4, kick: 120, id: 'reactor_target_2', type: 'target', score: SCORE.targetHit, litUntil: 0 });
        this.circles.push({ x: 40,  y: 300, r: 7, e: 0.4, kick: 110, id: 'bank_1', type: 'target', score: SCORE.targetHit, litUntil: 0 });
        this.circles.push({ x: 40,  y: 330, r: 7, e: 0.4, kick: 110, id: 'bank_2', type: 'target', score: SCORE.targetHit, litUntil: 0 });
        this.circles.push({ x: 40,  y: 360, r: 7, e: 0.4, kick: 110, id: 'bank_3', type: 'target', score: SCORE.targetHit, litUntil: 0 });

        // Two flippers (pivots near the bottom, tips angled inward toward the drain gap).
        const fy = PH - 70;
        this.flippers.push({ side: 'left',  px: 118,        py: fy, len: 74, r: 7, rest: Math.PI * 0.16, active: -Math.PI * 0.18, angle: Math.PI * 0.16, prevAngle: Math.PI * 0.16, angVel: 0, down: false, e: 0.32 });
        this.flippers.push({ side: 'right', px: LANE_X - 118, py: fy, len: 74, r: 7, rest: Math.PI * 0.84, active: Math.PI * 1.18, angle: Math.PI * 0.84, prevAngle: Math.PI * 0.84, angVel: 0, down: false, e: 0.32 });

        // Skill-shot rollover zone at the top of the launch lane.
        this.zones.push({ id: 'skillshot_lane', x: LANE_X - 10, y: 110, w: 30, h: 40, dimension: 'matter', _inside: new Set() });

        // ── Dimension-specific demo routes (Phase 3 framework: collision filtering
        // + ghost previews of inactive realities). Real per-dimension layouts land
        // in Phases 4–7. `dims` tags which realities the collider exists in.
        this.segments.push({ x1: 150, y1: 348, x2: 250, y2: 320, thick: 4, e: 0.55, id: 'particle_rail', type: 'slingshot', kick: 200, dims: ['particle'] });

        // Gravity wells (gravity dimension): attract the ball from a distance so
        // shots bend into orbits. `well`/`wellStrength` drive the force field; the
        // ball still bounces gently off the dense core (low kick). Orbiting a well
        // a full revolution pays an escalating orbit bonus (TDD §4 "Gravity").
        this.circles.push({ x: 196, y: 372, r: 16, e: 0.6, kick: 0, id: 'gravity_well', type: 'bumper', score: SCORE.bumperHit, litUntil: 0, dims: ['gravity'], well: true, wellStrength: 1.0 });
        this.circles.push({ x: 108, y: 232, r: 12, e: 0.6, kick: 0, id: 'gravity_well_2', type: 'bumper', score: SCORE.bumperHit, litUntil: 0, dims: ['gravity'], well: true, wellStrength: 0.7 });

        // Force-field + orbit-tracking state for each well.
        this.wells = this.circles.filter((c) => c.well);
        for (const w of this.wells) { w._orbAngle = 0; w._orbAccum = 0; w._orbActive = false; w._orbCount = 0; }

        // ── Shadow dimension (Phase 6): phasing walls + ghost targets + lock scoop.
        // The two wall groups alternate solid/intangible (phaseGroup vs _shadowPhase)
        // so a timed gap opens between them — pass through on the right beat. Ghost
        // targets only exist (and score) in shadow; the lock scoop captures the ball
        // for a big bonus then ejects it back up the table. Risk: the table is dark
        // and walls dissolve, but shadow pays the highest multiplier (2.5×).
        this.segments.push({ x1: 132, y1: 150, x2: 132, y2: 244, thick: 5, e: 0.4, id: 'phase_wall_a', type: 'wall', dims: ['shadow'], phaseGroup: 0 });
        this.segments.push({ x1: 228, y1: 150, x2: 228, y2: 244, thick: 5, e: 0.4, id: 'phase_wall_b', type: 'wall', dims: ['shadow'], phaseGroup: 1 });
        this.circles.push({ x: 70,  y: 150, r: 9, e: 0.4, kick: 90, id: 'ghost_target_1', type: 'target', score: SCORE.targetHit, litUntil: 0, dims: ['shadow'] });
        this.circles.push({ x: 290, y: 150, r: 9, e: 0.4, kick: 90, id: 'ghost_target_2', type: 'target', score: SCORE.targetHit, litUntil: 0, dims: ['shadow'] });
        this.zones.push({ id: 'shadow_lock', x: 168, y: 196, w: 24, h: 30, dimension: 'shadow', lock: true, _inside: new Set() });
    }
}

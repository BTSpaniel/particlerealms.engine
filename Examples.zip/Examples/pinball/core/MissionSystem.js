/**
 * MissionSystem — the 5-stage objective chain (TDD §10.1).
 *
 * Following modern pinball structure (modes played throughout a game on the way
 * to a gated WIZARD MODE), dimensions stay freely selectable like modes, while
 * this mandatory chain builds toward the wizard mode: the REACTOR MELTDOWN.
 *
 * Stages are sequential — only the current objective is live; clearing it pays a
 * bonus and advances the chain. Each stage is themed around one reality so the
 * player naturally tours every dimension. Clearing all five ARMS the wizard mode
 * (`reactor.armGrand()`): the next core-shot meltdown pays the GRAND reactor
 * jackpot. Emits `MISSION_CHANGED` for the HUD.
 */
import { PinballEvents } from './PinballEventBus.js';
import { SCORE } from './PinballSimWorld.js';

export class MissionSystem {
    constructor(sim, bus, reactor) {
        this.sim = sim;
        this.bus = bus;
        this.reactor = reactor;
        this.index = 0;
        this.wizardReady = false;

        // Each stage: which event proves it, an optional predicate, the reward.
        this._stages = [
            { id: 'power_up',       title: 'Power Up — score 5,000',          evt: PinballEvents.SCORE,        test: () => this.sim.score >= 5000,        reward: SCORE.comboShot },
            { id: 'particle_charge',title: 'Particle — fire a plasma surge',   evt: PinballEvents.PLASMA_SURGE, test: () => true,                          reward: SCORE.comboShot },
            { id: 'gravity_orbit',  title: 'Gravity — complete an orbit',      evt: PinballEvents.ORBIT,        test: () => true,                          reward: SCORE.comboShot },
            { id: 'shadow_lock',    title: 'Shadow — lock the ball',           evt: PinballEvents.BALL_ENTER_ZONE, test: (e) => e.zoneId === 'shadow_lock', reward: SCORE.comboShot },
            { id: 'resonance_sync', title: 'Resonance — 4× on-beat combo',     evt: PinballEvents.RESONANCE,    test: (e) => (e.combo || 0) >= 4,          reward: SCORE.jackpot },
        ];

        this._evt = { stageIndex: 0, stageId: '', title: '', status: 'active', bonus: 0, wizardReady: false };

        // One subscription per distinct event the chain cares about.
        const types = [...new Set(this._stages.map((s) => s.evt))];
        this._subs = types.map((t) => this.bus.on(t, (payload) => this._onEvent(t, payload)));

        this._emit('active');
    }

    get current() { return this._stages[this.index] ?? null; }

    _onEvent(type, payload) {
        if (this._completing) return; // guard: addScore re-emits SCORE synchronously
        const stage = this.current;
        if (!stage || this.wizardReady) return;
        if (stage.evt !== type) return;
        if (!stage.test(payload)) return;
        this._complete(stage);
    }

    _complete(stage) {
        this._completing = true;
        this.sim.addScore(stage.reward, 'mission');
        this._completing = false;
        this._emit('complete', stage.reward);
        this.index += 1;
        if (this.index >= this._stages.length) {
            this.wizardReady = true;
            this.reactor?.armGrand();
            this._emitWizard();
        } else {
            this._emit('active');
        }
    }

    _emit(status, bonus = 0) {
        const s = this.current;
        const e = this._evt;
        e.stageIndex = this.index;
        e.stageId = s?.id ?? 'done';
        e.title = s?.title ?? 'All missions complete';
        e.status = status; e.bonus = bonus; e.wizardReady = this.wizardReady;
        this.bus.emit(PinballEvents.MISSION, e);
    }

    _emitWizard() {
        const e = this._evt;
        e.stageIndex = this._stages.length;
        e.stageId = 'wizard';
        e.title = 'WIZARD MODE — shoot the core for the GRAND jackpot!';
        e.status = 'wizard'; e.bonus = 0; e.wizardReady = true;
        this.bus.emit(PinballEvents.MISSION, e);
    }

    destroy() { for (const u of this._subs) u?.(); this._subs = []; }
}

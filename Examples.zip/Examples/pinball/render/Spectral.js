/**
 * Spectral.js — maps a dimension's spectral band (nm) to display RGB (TDD §8).
 *
 * Reuses the engine's physically-based spectral pipeline
 * (`render/spectral/SpectralSensor.js`: CIE colour-matching → linear sRGB →
 * gamma) rather than a hand-rolled ramp. That module only imports pure
 * constants, so it's safe to pull into an OS app with no GPU side effects.
 *
 * Each reality emits light in its own wavelength band (see `Dimensions.js`);
 * sampling within the band at a shifting fraction `t` gives the signature colour
 * plus an interference-like shimmer when `t` is swept by the resonance state.
 */
import {
    wavelengthToXyz,
    xyzToLinearSrgb,
    encodeSrgbChannel,
} from '../../../../engine/render/spectral/SpectralSensor.js';

const _cache = new Map(); // nm(rounded) → [r,g,b], spectral conversion is pure

/** Wavelength (nm) → display sRGB [r,g,b] in 0..1. Cached per-nm. */
export function wavelengthRGB(nm) {
    const key = Math.round(nm);
    let rgb = _cache.get(key);
    if (rgb) return rgb;
    const lin = xyzToLinearSrgb(wavelengthToXyz(key, 1));
    rgb = [encodeSrgbChannel(lin[0]), encodeSrgbChannel(lin[1]), encodeSrgbChannel(lin[2])];
    // Renormalize so the band colour reads vividly as an emissive tint.
    const m = Math.max(rgb[0], rgb[1], rgb[2], 1e-3);
    rgb = [rgb[0] / m, rgb[1] / m, rgb[2] / m];
    _cache.set(key, rgb);
    return rgb;
}

/** Sample a [minNm,maxNm] band at fraction t∈[0,1] → display sRGB. */
export function bandRGB(band, t = 0.5) {
    const lo = band?.[0] ?? 520, hi = band?.[1] ?? 560;
    const tt = t < 0 ? 0 : t > 1 ? 1 : t;
    return wavelengthRGB(lo + (hi - lo) * tt);
}

/**
 * SurfaceRenderer — Phase 0 WebGPU bring-up for Dimensional Pinball.
 *
 * Validates that the kernel-provided OS GPU surface (shared device + already
 * configured GPUCanvasContext from SurfaceManager) can be driven from inside
 * the app: it clears the surface and draws one animated triangle each frame.
 *
 * Later phases replace the triangle pass with the engine SceneRenderer pass
 * stack (meshes → raymarch → particles → post-FX → spectral) on this same
 * surface; this class stays the thin owner of the per-frame encode/submit.
 */

const SHADER_WGSL = /* wgsl */`
struct Uni { time: f32, aspect: f32, _p0: f32, _p1: f32 };
@group(0) @binding(0) var<uniform> u : Uni;

struct VOut { @builtin(position) pos: vec4<f32>, @location(0) col: vec3<f32> };

@vertex
fn vs(@builtin(vertex_index) i: u32) -> VOut {
    var P = array<vec2<f32>, 3>(
        vec2<f32>( 0.0,  0.52),
        vec2<f32>(-0.46, -0.40),
        vec2<f32>( 0.46, -0.40)
    );
    var C = array<vec3<f32>, 3>(
        vec3<f32>(0.35, 0.49, 1.00),
        vec3<f32>(0.12, 0.82, 0.71),
        vec3<f32>(0.70, 0.42, 1.00)
    );
    let a  = u.time;
    let s  = sin(a);
    let cs = cos(a);
    var v  = P[i];
    v = vec2<f32>(v.x * cs - v.y * s, v.x * s + v.y * cs);
    v.x = v.x / max(u.aspect, 0.0001);
    var o: VOut;
    o.pos = vec4<f32>(v, 0.0, 1.0);
    o.col = C[i];
    return o;
}

@fragment
fn fs(in: VOut) -> @location(0) vec4<f32> {
    return vec4<f32>(in.col, 1.0);
}
`;

export class SurfaceRenderer {
    /** @param {{device:GPUDevice, context:GPUCanvasContext, format:GPUTextureFormat, width:number, height:number}} surface */
    constructor(surface) {
        this._surface  = surface;
        this._device   = surface.device;
        this._pipeline = null;
        this._uniformBuf = null;
        this._bindGroup  = null;
        this._destroyed  = false;
    }

    async init() {
        const device = this._device;
        const module = device.createShaderModule({ code: SHADER_WGSL });

        this._uniformBuf = device.createBuffer({
            size:  16, // time, aspect, 2× pad (std140 16-byte min)
            usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
        });

        this._pipeline = device.createRenderPipeline({
            layout: 'auto',
            vertex:   { module, entryPoint: 'vs' },
            fragment: { module, entryPoint: 'fs', targets: [{ format: this._surface.format }] },
            primitive: { topology: 'triangle-list' },
        });

        this._bindGroup = device.createBindGroup({
            layout: this._pipeline.getBindGroupLayout(0),
            entries: [{ binding: 0, resource: { buffer: this._uniformBuf } }],
        });
    }

    /** Encode + submit one frame. @param {number} t seconds since mount. */
    render(t) {
        if (this._destroyed || !this._pipeline) return;
        const device  = this._device;
        const context = this._surface.context;

        const w = this._surface.width  || 1;
        const h = this._surface.height || 1;
        device.queue.writeBuffer(this._uniformBuf, 0, new Float32Array([t, w / h, 0, 0]));

        let view;
        try { view = context.getCurrentTexture().createView(); }
        catch { return; } // surface resizing/unconfigured this frame

        const encoder = device.createCommandEncoder();
        const pass = encoder.beginRenderPass({
            colorAttachments: [{
                view,
                clearValue: { r: 0.02, g: 0.027, b: 0.043, a: 1 },
                loadOp:  'clear',
                storeOp: 'store',
            }],
        });
        pass.setPipeline(this._pipeline);
        pass.setBindGroup(0, this._bindGroup);
        pass.draw(3);
        pass.end();
        device.queue.submit([encoder.finish()]);
    }

    destroy() {
        this._destroyed = true;
        this._uniformBuf?.destroy?.();
        this._uniformBuf = null;
        this._pipeline   = null;
        this._bindGroup  = null;
    }
}

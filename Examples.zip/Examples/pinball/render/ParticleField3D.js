/**
 * ParticleField3D — GPU particle field for the 3D table (Phase 4+).
 *
 * Mirrors the proven OS/playground pattern (apps/particles/ParticleApp.js +
 * tests/playground): a storage buffer of particles updated by a compute shader,
 * drawn as instanced camera-facing billboards with additive premultiplied
 * blending — all on the raw kernel surface device. (The engine's full
 * `ParticleSimWorld` is ECS/VGPU-coupled and too heavy for an OS app.)
 *
 * Particles live in WORLD space and share TableRenderer3D's view-proj + depth,
 * so they're occluded by the table yet glow in front of it. CPU spawns bursts
 * (collisions, ball trail, charged bumpers) into a ring of slots; the compute
 * pass integrates motion + fades by remaining life.
 *
 * Layout per particle = 3×vec4 (48 bytes): a=(x,y,z,life) b=(vx,vy,vz,size) c=rgba.
 */

const STRIDE_F = 12;          // floats per particle
const STRIDE_B = STRIDE_F * 4; // 48 bytes

const COMPUTE_WGSL = /* wgsl */`
struct P { a: vec4<f32>, b: vec4<f32>, c: vec4<f32> };
struct U { dt: f32, gravity: f32, drag: f32, _pad: f32 };
@group(0) @binding(0) var<storage, read_write> pts: array<P>;
@group(0) @binding(1) var<uniform> u: U;

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
    let i = gid.x;
    if (i >= arrayLength(&pts)) { return; }
    var p = pts[i];
    if (p.a.w <= 0.0) { p.b.w = 0.0; p.c.a = 0.0; pts[i] = p; return; }
    p.a.w = p.a.w - u.dt;
    var v = p.b.xyz;
    v.y = v.y - u.gravity * u.dt;
    v = v * u.drag;
    p.a = vec4<f32>(p.a.xyz + v * u.dt, p.a.w);
    p.b = vec4<f32>(v, p.b.w);
    p.c.a = clamp(p.a.w * 3.0, 0.0, 1.0);
    pts[i] = p;
}
`;

const RENDER_WGSL = /* wgsl */`
struct P { a: vec4<f32>, b: vec4<f32>, c: vec4<f32> };
struct R { viewProj: mat4x4<f32>, camRight: vec4<f32>, camUp: vec4<f32> };
@group(0) @binding(0) var<storage, read> pts: array<P>;
@group(0) @binding(1) var<uniform> r: R;

struct VO { @builtin(position) pos: vec4<f32>, @location(0) uv: vec2<f32>, @location(1) col: vec4<f32> };

@vertex
fn vs(@builtin(vertex_index) vi: u32, @builtin(instance_index) ii: u32) -> VO {
    var corners = array<vec2<f32>, 6>(
        vec2<f32>(-1.0, -1.0), vec2<f32>(1.0, -1.0), vec2<f32>(-1.0, 1.0),
        vec2<f32>(-1.0,  1.0), vec2<f32>(1.0, -1.0), vec2<f32>( 1.0, 1.0)
    );
    let p = pts[ii];
    var o: VO;
    let size = p.b.w;
    if (size <= 0.0 || p.c.a <= 0.0) {
        o.pos = vec4<f32>(0.0, 0.0, -10.0, 1.0); // behind near plane → clipped
        o.uv = vec2<f32>(0.0);
        o.col = vec4<f32>(0.0);
        return o;
    }
    let corner = corners[vi];
    let wp = p.a.xyz + r.camRight.xyz * corner.x * size + r.camUp.xyz * corner.y * size;
    o.pos = r.viewProj * vec4<f32>(wp, 1.0);
    o.uv = corner;
    o.col = p.c;
    return o;
}

@fragment
fn fs(in: VO) -> @location(0) vec4<f32> {
    let d = length(in.uv);
    if (d > 1.0) { discard; }
    let fall = 1.0 - d * d;
    let a = in.col.a * fall;
    return vec4<f32>(in.col.rgb * a, a); // premultiplied additive glow
}
`;

export class ParticleField3D {
    constructor(device, format, maxParticles = 3000) {
        this.device = device;
        this.format = format;
        this.max = maxParticles;
        this._buf = null;
        this._paramsBuf = null;
        this._renderUni = null;
        this._computePipeline = null;
        this._renderPipeline = null;
        this._computeBG = null;
        this._renderBG = null;
        this._cursor = 0;
        this._params = new Float32Array(4);
        this._renderData = new Float32Array(24); // viewProj(16) + camRight(4) + camUp(4)
    }

    async init() {
        const device = this.device;
        this._buf = device.createBuffer({
            size: this.max * STRIDE_B,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
        });
        this._paramsBuf = device.createBuffer({ size: 16, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
        this._renderUni = device.createBuffer({ size: 96, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });

        const cMod = device.createShaderModule({ code: COMPUTE_WGSL });
        this._computePipeline = device.createComputePipeline({ layout: 'auto', compute: { module: cMod, entryPoint: 'main' } });
        this._computeBG = device.createBindGroup({
            layout: this._computePipeline.getBindGroupLayout(0),
            entries: [
                { binding: 0, resource: { buffer: this._buf } },
                { binding: 1, resource: { buffer: this._paramsBuf } },
            ],
        });

        const rMod = device.createShaderModule({ code: RENDER_WGSL });
        this._renderPipeline = device.createRenderPipeline({
            layout: 'auto',
            vertex: { module: rMod, entryPoint: 'vs' },
            fragment: { module: rMod, entryPoint: 'fs', targets: [{
                format: this.format,
                blend: {
                    color: { srcFactor: 'one', dstFactor: 'one', operation: 'add' },
                    alpha: { srcFactor: 'one', dstFactor: 'one', operation: 'add' },
                },
            }] },
            primitive: { topology: 'triangle-list' },
            depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'less' },
        });
        this._renderBG = device.createBindGroup({
            layout: this._renderPipeline.getBindGroupLayout(0),
            entries: [
                { binding: 0, resource: { buffer: this._buf } },
                { binding: 1, resource: { buffer: this._renderUni } },
            ],
        });
    }

    /**
     * Spawn a burst of particles at a world position.
     * @param {number[]} pos   world [x,y,z]
     * @param {number[]} color [r,g,b]
     * @param {object} [o] { count, speed, size, life, spread, dir:[x,y,z] }
     */
    spawn(pos, color, o = {}) {
        if (!this._buf) return;
        const count = Math.min(o.count ?? 10, this.max);
        const speed = o.speed ?? 2.0;
        const size = o.size ?? 0.06;
        const life = o.life ?? 0.7;
        const spread = o.spread ?? 1.0;
        const dir = o.dir;
        const data = new Float32Array(count * STRIDE_F);
        for (let k = 0; k < count; k++) {
            // Random unit-ish direction (biased toward dir when provided).
            let dx = (Math.random() * 2 - 1), dy = (Math.random() * 2 - 1), dz = (Math.random() * 2 - 1);
            let l = Math.hypot(dx, dy, dz) || 1; dx /= l; dy /= l; dz /= l;
            if (dir) { dx = dir[0] * (1 - spread) + dx * spread; dy = dir[1] * (1 - spread) + dy * spread; dz = dir[2] * (1 - spread) + dz * spread; }
            const sp = speed * (0.5 + Math.random() * 0.7);
            const b = k * STRIDE_F;
            data[b + 0] = pos[0]; data[b + 1] = pos[1]; data[b + 2] = pos[2];
            data[b + 3] = life * (0.7 + Math.random() * 0.6); // life
            data[b + 4] = dx * sp; data[b + 5] = dy * sp + 0.5; data[b + 6] = dz * sp;
            data[b + 7] = size * (0.7 + Math.random() * 0.8); // size
            data[b + 8] = color[0]; data[b + 9] = color[1]; data[b + 10] = color[2];
            data[b + 11] = 1.0; // alpha
        }
        // Ring write (split if it wraps past the end of the buffer).
        const start = this._cursor % this.max;
        const fit = Math.min(count, this.max - start);
        this.device.queue.writeBuffer(this._buf, start * STRIDE_B, data, 0, fit * STRIDE_F);
        if (fit < count) {
            this.device.queue.writeBuffer(this._buf, 0, data, fit * STRIDE_F, (count - fit) * STRIDE_F);
        }
        this._cursor = (start + count) % this.max;
    }

    /** Compute pass — integrate motion + fade. Records into the provided encoder. */
    compute(encoder, dt) {
        if (!this._computePipeline) return;
        this._params[0] = Math.min(dt, 0.05);
        this._params[1] = 3.0;   // gravity (world units/s²)
        this._params[2] = 0.985; // per-step drag
        this.device.queue.writeBuffer(this._paramsBuf, 0, this._params);
        const cp = encoder.beginComputePass();
        cp.setPipeline(this._computePipeline);
        cp.setBindGroup(0, this._computeBG);
        cp.dispatchWorkgroups(Math.ceil(this.max / 64));
        cp.end();
    }

    /** Render pass — draw billboards. Call inside an active render pass. */
    render(pass, viewProj, camRight, camUp) {
        if (!this._renderPipeline) return;
        const d = this._renderData;
        d.set(viewProj, 0);
        d[16] = camRight[0]; d[17] = camRight[1]; d[18] = camRight[2]; d[19] = 0;
        d[20] = camUp[0]; d[21] = camUp[1]; d[22] = camUp[2]; d[23] = 0;
        this.device.queue.writeBuffer(this._renderUni, 0, d);
        pass.setPipeline(this._renderPipeline);
        pass.setBindGroup(0, this._renderBG);
        pass.draw(6, this.max);
    }

    destroy() {
        this._buf?.destroy?.();
        this._paramsBuf?.destroy?.();
        this._renderUni?.destroy?.();
        this._buf = this._paramsBuf = this._renderUni = null;
        this._computePipeline = this._renderPipeline = null;
    }
}

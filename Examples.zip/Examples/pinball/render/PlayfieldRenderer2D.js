/**
 * PlayfieldRenderer2D — Phase 1 gameplay visualization (Canvas 2D overlay).
 *
 * Draws the authoritative sim state (walls, bumpers, targets, flippers, ball,
 * launch charge) so the Matter table can be tuned to feel fun BEFORE the
 * Phase 2 engine 3D renderer replaces it on the GPU surface. Deliberately
 * effect-free per the TDD Phase 1 exit criterion ("fun without effects").
 *
 * Logical playfield (PW×PH) is letterboxed into the canvas, preserving aspect.
 */
export class PlayfieldRenderer2D {
    /** @param {HTMLCanvasElement} canvas */
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this._sx = 1; this._ox = 0; this._oy = 0;
    }

    render(state, charge = 0) {
        const ctx = this.ctx;
        if (!ctx) return;
        const cw = this.canvas.width, ch = this.canvas.height;
        const { PW, PH } = state;

        const scale = Math.min(cw / PW, ch / PH);
        const ox = (cw - PW * scale) / 2;
        const oy = (ch - PH * scale) / 2;
        this._sx = scale; this._ox = ox; this._oy = oy;
        const X = (x) => ox + x * scale;
        const Y = (y) => oy + y * scale;
        const S = (v) => v * scale;
        const now = state.now ?? 0;

        // Backdrop + playfield.
        ctx.fillStyle = '#04060a';
        ctx.fillRect(0, 0, cw, ch);
        const grad = ctx.createLinearGradient(0, oy, 0, oy + PH * scale);
        grad.addColorStop(0, '#0b1220');
        grad.addColorStop(1, '#070a12');
        ctx.fillStyle = grad;
        ctx.fillRect(ox, oy, PW * scale, PH * scale);

        // Segments.
        ctx.lineCap = 'round';
        for (const sg of state.segments) {
            ctx.beginPath();
            ctx.moveTo(X(sg.x1), Y(sg.y1));
            ctx.lineTo(X(sg.x2), Y(sg.y2));
            ctx.lineWidth = Math.max(1.5, S(sg.thick * 2));
            ctx.strokeStyle = sg.type === 'slingshot' ? 'rgba(91,124,255,0.85)'
                : sg.type === 'wall' ? 'rgba(150,170,210,0.45)'
                : 'rgba(120,140,180,0.30)';
            ctx.stroke();
        }

        // Circles (bumpers + targets).
        for (const c of state.circles) {
            const lit = now < c.litUntil;
            ctx.beginPath();
            ctx.arc(X(c.x), Y(c.y), S(c.r), 0, Math.PI * 2);
            if (c.type === 'bumper') {
                ctx.fillStyle = lit ? 'rgba(31,210,180,0.75)' : 'rgba(31,210,180,0.16)';
                ctx.strokeStyle = lit ? '#5cf0d2' : 'rgba(31,210,180,0.5)';
            } else {
                ctx.fillStyle = lit ? 'rgba(255,210,127,0.9)' : 'rgba(255,210,127,0.3)';
                ctx.strokeStyle = 'rgba(255,210,127,0.7)';
            }
            ctx.lineWidth = Math.max(1.5, S(2.5));
            ctx.fill();
            ctx.stroke();
        }

        // Flippers.
        for (const f of state.flippers) {
            const tx = f.px + Math.cos(f.angle) * f.len;
            const ty = f.py + Math.sin(f.angle) * f.len;
            ctx.beginPath();
            ctx.moveTo(X(f.px), Y(f.py));
            ctx.lineTo(X(tx), Y(ty));
            ctx.lineWidth = Math.max(2, S(f.r * 2));
            ctx.strokeStyle = '#5b7cff';
            ctx.stroke();
            ctx.beginPath();
            ctx.arc(X(f.px), Y(f.py), Math.max(2, S(f.r + 1)), 0, Math.PI * 2);
            ctx.fillStyle = '#3a5aee';
            ctx.fill();
        }

        // Ball(s).
        for (const b of state.balls) {
            const bx = X(b.x), by = Y(b.y), br = S(state.ballR);
            const g = ctx.createRadialGradient(bx - br * 0.3, by - br * 0.3, br * 0.1, bx, by, br);
            g.addColorStop(0, '#ffffff');
            g.addColorStop(0.45, '#a8c0ff');
            g.addColorStop(1, '#2f44bb');
            ctx.beginPath();
            ctx.arc(bx, by, br, 0, Math.PI * 2);
            ctx.fillStyle = g;
            ctx.shadowColor = '#5b7cff';
            ctx.shadowBlur = br * 1.4;
            ctx.fill();
            ctx.shadowBlur = 0;
        }

        // Launch charge meter (bottom-right lane).
        if (charge > 0) {
            const mx = X(PW - 18), my0 = Y(PH - 40), h = S(120) * charge;
            ctx.fillStyle = `rgba(91,124,255,${0.25 + charge * 0.6})`;
            ctx.fillRect(mx - S(5), my0 - h, S(10), h);
        }

        // State overlays.
        ctx.textAlign = 'center';
        if (state.state === 'ready') {
            ctx.fillStyle = 'rgba(232,240,255,0.55)';
            ctx.font = `${Math.round(S(14))}px Inter, system-ui, sans-serif`;
            ctx.fillText('Hold Space (or tap lower-right) to launch', cw / 2, oy + PH * scale - S(22));
        } else if (state.state === 'lost') {
            ctx.fillStyle = 'rgba(5,7,11,0.78)';
            ctx.fillRect(ox, oy, PW * scale, PH * scale);
            ctx.fillStyle = '#ff6b6b';
            ctx.font = `bold ${Math.round(S(30))}px Inter, system-ui, sans-serif`;
            ctx.fillText('GAME OVER', cw / 2, ch / 2 - S(16));
            ctx.fillStyle = 'rgba(232,240,255,0.8)';
            ctx.font = `${Math.round(S(15))}px Inter, system-ui, sans-serif`;
            ctx.fillText('Score: ' + state.score.toLocaleString(), cw / 2, ch / 2 + S(14));
            ctx.fillStyle = '#5b7cff';
            ctx.fillText('Click to play again', cw / 2, ch / 2 + S(40));
        }
        ctx.textAlign = 'left';
    }
}

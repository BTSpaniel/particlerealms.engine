/**
 * TableRenderer3D — Phase 2 "Reactor" table renderer on the OS GPU surface.
 *
 * Renders the authoritative sim state as lit 3D primitives (playfield, walls,
 * slingshots, bumpers, targets, flippers, ball) using the kernel-shared
 * GPUDevice + canvas context. Geometry comes from the engine's `createMesh`
 * (GeometryFactory); a single forward pipeline with Blinn-Phong lighting +
 * emissive (bumpers glow when hit) keeps the ball and flippers readable
 * (TDD Phase 2 exit: premium look, always-legible play).
 *
 * Per-object data is uploaded through one dynamic-offset uniform buffer (one
 * 256-byte slot per node), so the whole table draws in a single render pass.
 * Spectral color, bloom, raymarched voxels, and post-FX arrive in later phases.
 */
import { TableCamera } from './TableCamera.js';
import { fromBasis, fromScaleTranslate } from './Mat4.js';
import { createBoxMesh, createCylinderMesh, createSphereMesh } from './GeometryFactory.js';
import { DIMENSIONS } from '../core/Dimensions.js';
import { MAX_BALLS } from '../core/PinballSimWorld.js';
import { ParticleField3D } from './ParticleField3D.js';
import { VolumetricCore } from './VolumetricCore.js';
import { bandRGB } from './Spectral.js';
import { PinballEvents } from '../core/PinballEventBus.js';

// Reactor state → additive brightness for the volumetric core orb.
const REACTOR_BOOST = Object.freeze({
    stable: 0, charged: 0.5, unstable: 1.1, critical: 1.9, meltdown: 3.4,
});

const WALL_H_SIM   = 22;
const BUMPER_H_SIM = 30;
const TARGET_H_SIM = 18;
const FLIPPER_H_SIM= 16;
const FIELD_THICK  = 10;

const COL = {
    field:    [0.05, 0.07, 0.12, 1],
    wall:     [0.50, 0.56, 0.66, 1],
    slingshot:[0.36, 0.49, 1.00, 1],
    guide:    [0.30, 0.34, 0.44, 1],
    bumper:   [0.12, 0.45, 0.42, 1],
    target:   [1.00, 0.82, 0.40, 1],
    flipper:  [0.40, 0.52, 1.00, 1],
    ball:     [0.86, 0.90, 1.00, 1],
};

const SHADER = /* wgsl */`
struct Frame { viewProj: mat4x4<f32>, camPos: vec4<f32>, lightDir: vec4<f32>, lightColor: vec4<f32>, ambient: vec4<f32> };
struct Obj   { model: mat4x4<f32>, baseColor: vec4<f32>, emissive: vec4<f32> };
@group(0) @binding(0) var<uniform> F: Frame;
@group(0) @binding(1) var<uniform> O: Obj;

struct VOut { @builtin(position) pos: vec4<f32>, @location(0) wpos: vec3<f32>, @location(1) wn: vec3<f32> };

@vertex
fn vs(@location(0) p: vec3<f32>, @location(1) n: vec3<f32>) -> VOut {
    let wp = O.model * vec4<f32>(p, 1.0);
    var o: VOut;
    o.pos  = F.viewProj * wp;
    o.wpos = wp.xyz;
    o.wn   = (O.model * vec4<f32>(n, 0.0)).xyz;
    return o;
}

@fragment
fn fs(i: VOut) -> @location(0) vec4<f32> {
    let N = normalize(i.wn);
    let L = normalize(-F.lightDir.xyz);
    let diff = max(dot(N, L), 0.0);
    let V = normalize(F.camPos.xyz - i.wpos);
    let H = normalize(L + V);
    let spec = pow(max(dot(N, H), 0.0), 28.0) * 0.28;
    var col = O.baseColor.rgb * (F.ambient.rgb + F.lightColor.rgb * diff) + vec3<f32>(spec);
    col = col + O.emissive.rgb * O.emissive.a;
    return vec4<f32>(col, O.baseColor.a);
}
`;

export class TableRenderer3D {
    constructor(surface, bus = null) {
        this.surface = surface;
        this.device  = surface.device;
        this.bus     = bus;
        this._particles = null;
        this._core   = null;  // raymarched reactor-core orb
        this._reactorBoost = 0; // extra core brightness driven by reactor state
        this._highContrastBall = false; // accessibility: bright outlined ball
        this._reson  = 0;     // decaying resonance glow [0..1] for spectral shimmer
        this._spectral = [1, 1, 1];
        this._unsub  = null;
        this._lastT  = 0;
        this.cam     = null;
        this._pipeline = null;
        this._bindGroup = null;
        this._frameBuf = null;
        this._objBuf = null;
        this._objStride = 256;
        this._meshes = {};
        this._nodes = [];
        this._depthTex = null;
        this._depthW = 0; this._depthH = 0;
        this._frame = new Float32Array(32);
        this._obj = new Float32Array(24);
        this._built = false;
    }

    async init() {
        const device = this.device;
        this._meshes.box = createBoxMesh(device);
        this._meshes.cyl = createCylinderMesh(device);
        this._meshes.sphere = createSphereMesh(device);

        const align = device.limits?.minUniformBufferOffsetAlignment ?? 256;
        this._objStride = Math.max(align, Math.ceil(96 / align) * align);

        const module = device.createShaderModule({ code: SHADER });
        const bgl = device.createBindGroupLayout({
            entries: [
                { binding: 0, visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: { type: 'uniform', minBindingSize: 128 } },
                { binding: 1, visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: { type: 'uniform', hasDynamicOffset: true, minBindingSize: 96 } },
            ],
        });
        const layout = device.createPipelineLayout({ bindGroupLayouts: [bgl] });

        this._pipeline = device.createRenderPipeline({
            layout,
            vertex: {
                module, entryPoint: 'vs',
                buffers: [{
                    arrayStride: 24,
                    attributes: [
                        { shaderLocation: 0, offset: 0,  format: 'float32x3' },
                        { shaderLocation: 1, offset: 12, format: 'float32x3' },
                    ],
                }],
            },
            fragment: { module, entryPoint: 'fs', targets: [{ format: this.surface.format }] },
            primitive: { topology: 'triangle-list', cullMode: 'none' },
            depthStencil: { format: 'depth24plus', depthWriteEnabled: true, depthCompare: 'less' },
        });

        // Ghost pipeline — translucent previews of inactive-dimension routes
        // (alpha-blended, no depth write so they don't occlude each other).
        this._ghostPipeline = device.createRenderPipeline({
            layout,
            vertex: {
                module, entryPoint: 'vs',
                buffers: [{
                    arrayStride: 24,
                    attributes: [
                        { shaderLocation: 0, offset: 0,  format: 'float32x3' },
                        { shaderLocation: 1, offset: 12, format: 'float32x3' },
                    ],
                }],
            },
            fragment: { module, entryPoint: 'fs', targets: [{
                format: this.surface.format,
                blend: {
                    color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha', operation: 'add' },
                    alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha', operation: 'add' },
                },
            }] },
            primitive: { topology: 'triangle-list', cullMode: 'none' },
            depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'less' },
        });

        this._frameBuf = device.createBuffer({ size: 128, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
        this._bgl = bgl;

        // GPU particle field — collision sparks, ball trail, charged FX.
        this._particles = new ParticleField3D(device, this.surface.format);
        await this._particles.init();
        this._core = new VolumetricCore(device, this.surface.format);
        this._core.init();
        if (this.bus) {
            this._unsub = this.bus.on(PinballEvents.COLLISION, (e) => this._onCollision(e));
            this._unsubP = this.bus.on(PinballEvents.PLASMA_SURGE, (e) => this._onPlasma(e));
            this._unsubO = this.bus.on(PinballEvents.ORBIT, (e) => this._onOrbit(e));
            this._unsubR = this.bus.on(PinballEvents.RESONANCE, (e) => this._onResonance(e));
            this._unsubReactor = this.bus.on(PinballEvents.REACTOR_STATE, (e) => {
                this._reactorBoost = REACTOR_BOOST[e.newState] ?? 0;
            });
        }
    }

    // ── Node construction (once, from sim geometry) ─────────────────────────────

    _build(state) {
        this.cam = new TableCamera(state.PW, state.PH);
        const cam = this.cam;
        const nodes = [];

        const segBasis = (model, x1, y1, x2, y2, h, thick) => {
            const ax = cam.wx(x1), az = cam.wz(y1), bx = cam.wx(x2), bz = cam.wz(y2);
            const dx = bx - ax, dz = bz - az;
            const len = Math.hypot(dx, dz) || 1e-4;
            const tw = cam.ws(thick);
            const px = -dz / len * tw, pz = dx / len * tw;
            fromBasis(model, [dx, 0, dz], [0, cam.ws(h), 0], [px, 0, pz], [(ax + bx) / 2, cam.ws(h) / 2, (az + bz) / 2]);
        };

        // Playfield slab.
        {
            const m = new Float32Array(16);
            fromScaleTranslate(m, cam.ws(state.PW), cam.ws(FIELD_THICK), cam.ws(state.PH), 0, -cam.ws(FIELD_THICK) / 2, 0);
            nodes.push({ mesh: this._meshes.box, model: m, color: COL.field, emissive: [0, 0, 0, 0], kind: 'static' });
        }

        // Walls / slingshots / guides.
        for (const sg of state.segments) {
            const m = new Float32Array(16);
            segBasis(m, sg.x1, sg.y1, sg.x2, sg.y2, WALL_H_SIM, (sg.thick + 2) * 1.4);
            const color = sg.type === 'slingshot' ? COL.slingshot : sg.type === 'wall' ? COL.wall : COL.guide;
            nodes.push({ mesh: this._meshes.box, model: m, color, emissive: [0, 0, 0, 0], kind: 'static', dims: sg.dims ?? null, phaseGroup: sg.phaseGroup });
        }

        // Bumpers + targets (cylinders); bumpers glow on hit.
        for (const c of state.circles) {
            const isBumper = c.type === 'bumper';
            const h = isBumper ? BUMPER_H_SIM : TARGET_H_SIM;
            const m = new Float32Array(16);
            const r = cam.ws(c.r);
            fromScaleTranslate(m, r, cam.ws(h), r, cam.wx(c.x), cam.ws(h) / 2, cam.wz(c.y));
            nodes.push({
                mesh: this._meshes.cyl, model: m,
                color: isBumper ? COL.bumper : COL.target,
                emissive: [0, 0, 0, 0], kind: isBumper ? 'bumper' : 'target', ref: c, dims: c.dims ?? null, phaseGroup: c.phaseGroup,
            });
        }

        // Flippers (recomputed each frame).
        for (const f of state.flippers) {
            nodes.push({ mesh: this._meshes.box, model: new Float32Array(16), color: COL.flipper, emissive: [0.18, 0.26, 0.7, 0.35], kind: 'flipper', ref: f });
        }

        // Ball pool — one node per possible multiball; only active ones draw.
        const ballColor = this._highContrastBall ? [1, 1, 1, 1] : COL.ball;
        const ballEmis  = this._highContrastBall ? [0.9, 0.95, 1.0, 0.85] : [0.25, 0.4, 1.0, 0.22];
        this._ballNodes = [];
        for (let k = 0; k < MAX_BALLS; k++) {
            const node = { mesh: this._meshes.sphere, model: new Float32Array(16), color: ballColor.slice(), emissive: ballEmis.slice(), kind: 'ball', visible: false };
            this._ballNodes.push(node);
            nodes.push(node);
        }

        this._nodes = nodes;
        this._segBasis = segBasis;

        // Object uniform buffer sized to node count.
        this._objBuf = this.device.createBuffer({ size: this._objStride * nodes.length, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
        this._bindGroup = this.device.createBindGroup({
            layout: this._bgl,
            entries: [
                { binding: 0, resource: { buffer: this._frameBuf, size: 128 } },
                { binding: 1, resource: { buffer: this._objBuf, size: 96 } },
            ],
        });
        this._built = true;
    }

    /** Accessibility: render the ball as a bright high-contrast sphere. */
    setHighContrastBall(on) {
        this._highContrastBall = !!on;
        const c = on ? [1, 1, 1, 1] : COL.ball;
        const e = on ? [0.9, 0.95, 1.0, 0.85] : [0.25, 0.4, 1.0, 0.22];
        for (const n of (this._ballNodes ?? [])) {
            n.color[0] = c[0]; n.color[1] = c[1]; n.color[2] = c[2]; n.color[3] = c[3];
            n.emissive[0] = e[0]; n.emissive[1] = e[1]; n.emissive[2] = e[2]; n.emissive[3] = e[3];
        }
    }

    _ensureDepth(w, h) {
        if (this._depthTex && this._depthW === w && this._depthH === h) return;
        this._depthTex?.destroy?.();
        this._depthTex = this.device.createTexture({
            size: [w, h], format: 'depth24plus', usage: GPUTextureUsage.RENDER_ATTACHMENT,
        });
        this._depthW = w; this._depthH = h;
    }

    // ── Per-frame ──────────────────────────────────────────────────────────────

    render(state) {
        if (!this._pipeline) return;
        if (!this._built) this._build(state);

        const w = this.surface.width | 0, h = this.surface.height | 0;
        if (w < 1 || h < 1) return;
        this._ensureDepth(w, h);

        const vp = this.cam.update(w, h);
        const now = performance.now();
        const dt = this._lastT ? Math.min(0.05, (now - this._lastT) / 1000) : 0.016;
        this._lastT = now;
        // Dimension palette → ambient/sun tint + accent (read each frame so a
        // DIMENSION_SHIFT recolors the whole table atomically with the physics).
        const dimDef = DIMENSIONS[state.dimension] ?? DIMENSIONS.matter;
        const prim = hexToRgb(dimDef.palette.primary);
        this._accent = hexToRgb(dimDef.palette.accent);
        // Spectral colour: sample the active reality's wavelength band, sweeping the
        // sample point over time (wider when resonating) for an interference shimmer
        // that reacts to the resonance state (TDD §8).
        this._reson = Math.max(0, this._reson - dt * 1.6);
        const shimmer = 0.5 + 0.45 * Math.sin(now * 0.0016) * (0.5 + this._reson * 0.5);
        this._spectral = bandRGB(dimDef.spectralBand, shimmer);

        // Frame uniform.
        const fr = this._frame;
        fr.set(vp, 0);
        fr[16] = this.cam.eye[0]; fr[17] = this.cam.eye[1]; fr[18] = this.cam.eye[2]; fr[19] = 1;
        const ld = normalize3(-0.3, -1.0, -0.4);
        fr[20] = ld[0]; fr[21] = ld[1]; fr[22] = ld[2]; fr[23] = 0;
        fr[24] = 1.0; fr[25] = 0.98; fr[26] = 0.92; fr[27] = 1;
        fr[28] = 0.11 + prim[0] * 0.14; fr[29] = 0.12 + prim[1] * 0.14; fr[30] = 0.15 + prim[2] * 0.16; fr[31] = 1;
        this.device.queue.writeBuffer(this._frameBuf, 0, fr);

        this._updateDynamic(state);

        // Ball trails (dimension-tinted), one per launched ball. Trail density is
        // halved in multiball and thinned near the flippers (TDD §13 density cap)
        // so the lower playfield stays readable when the table is busy.
        if (this._particles && this.cam) {
            const dd = DIMENSIONS[state.dimension] ?? DIMENSIONS.matter;
            const tc = hexToRgb(dd.palette.core ?? dd.palette.primary);
            const multi = state.balls.length > 1 ? 0.5 : 1;
            const base = Math.max(1, Math.round((dd.particleDensity ?? 1) * multi));
            const flipperY = state.PH * 0.72;
            for (const bb of state.balls) {
                if (!bb.launched) continue;
                const cnt = bb.y > flipperY ? Math.max(1, Math.floor(base * 0.4)) : base;
                this._particles.spawn([this.cam.wx(bb.x), this.cam.ws(state.ballR), this.cam.wz(bb.y)], tc, { count: cnt, speed: 0.35, size: 0.05, life: 0.4, spread: 1.0 });
            }
        }

        let view;
        try { view = this.surface.context.getCurrentTexture().createView(); }
        catch { return; }

        const encoder = this.device.createCommandEncoder();
        if (this._particles) this._particles.compute(encoder, dt);
        const pass = encoder.beginRenderPass({
            colorAttachments: [{ view, clearValue: { r: 0.015 + prim[0] * 0.02, g: 0.022 + prim[1] * 0.02, b: 0.04 + prim[2] * 0.03, a: 1 }, loadOp: 'clear', storeOp: 'store' }],
            depthStencilAttachment: { view: this._depthTex.createView(), depthClearValue: 1.0, depthLoadOp: 'clear', depthStoreOp: 'store' },
        });

        const ob = this._obj;
        const active = state.dimension;
        const sp = state.shadowPhase ?? 0;
        // A node is solid now if it belongs to the active reality AND (if it phases)
        // its phase group matches the current shadow phase. Otherwise it ghosts.
        const isSolid = (n) => {
            if (n.dims && !n.dims.includes(active)) return false;
            if (n.phaseGroup !== undefined && sp !== n.phaseGroup) return false;
            return true;
        };
        const drawNode = (i, color, emissive) => {
            const n = this._nodes[i];
            ob.set(n.model, 0);
            ob[16] = color[0]; ob[17] = color[1]; ob[18] = color[2]; ob[19] = color[3];
            ob[20] = emissive[0]; ob[21] = emissive[1]; ob[22] = emissive[2]; ob[23] = emissive[3];
            const off = i * this._objStride;
            this.device.queue.writeBuffer(this._objBuf, off, ob);
            pass.setBindGroup(0, this._bindGroup, [off]);
            pass.setVertexBuffer(0, n.mesh.vertexBuffer);
            pass.setIndexBuffer(n.mesh.indexBuffer, n.mesh.indexFormat);
            pass.drawIndexed(n.mesh.indexCount);
        };

        // Opaque pass — universal colliders + those active+solid in the current reality.
        pass.setPipeline(this._pipeline);
        for (let i = 0; i < this._nodes.length; i++) {
            const n = this._nodes[i];
            if (n.kind === 'ball' && !n.visible) continue;
            if (!isSolid(n)) continue; // other reality or phased-out → ghost pass
            drawNode(i, n.color, n.emissive);
        }

        // Ghost pass — faint previews of inactive-reality routes AND phased-out
        // shadow walls (which dissolve to a translucent outline while intangible).
        pass.setPipeline(this._ghostPipeline);
        for (let i = 0; i < this._nodes.length; i++) {
            const n = this._nodes[i];
            if (!n.dims || isSolid(n)) continue;
            const gdim = n.dims.includes(active) ? active : n.dims[0];
            const gp = DIMENSIONS[gdim] ?? DIMENSIONS.matter;
            const gc = hexToRgb(gp.palette.accent);
            drawNode(i, [gc[0], gc[1], gc[2], 0.16], [gc[0], gc[1], gc[2], 0.5]);
        }

        // Raymarched reactor-core orb — proxy volume sharing the depth buffer, so
        // rails/walls in front correctly occlude it (TDD §9 depth test).
        if (this._core && this._meshes.box) {
            const cam = this.cam;
            const center = [cam.wx(state.PW / 2), cam.ws(54), cam.wz(200)];
            const intensity = 0.5 + this._reson * 1.4 + this._reactorBoost;
            this._core.render(pass, this._meshes.box, vp, cam.eyeFlat, center, cam.ws(48), this._spectral, intensity, now * 0.001);
        }

        // Particle field (additive glow) — shares the camera + depth buffer.
        if (this._particles) this._particles.render(pass, vp, this.cam.right, this.cam.up);

        pass.end();
        this.device.queue.submit([encoder.finish()]);
    }

    _updateDynamic(state) {
        const cam = this.cam;
        const now = state.now ?? 0;
        for (const n of this._nodes) {
            if (n.kind === 'bumper' || n.kind === 'target') {
                // Spectral emissive: pops on a fresh hit, and all scoring objects
                // shimmer together with the resonance pulse (interference reacting
                // to resonance).
                const lit = now < (n.ref.litUntil ?? 0);
                const s = this._spectral;
                const intensity = lit ? 1.6 : this._reson * 1.1;
                n.emissive[0] = s[0]; n.emissive[1] = s[1]; n.emissive[2] = s[2];
                n.emissive[3] = intensity;
            } else if (n.kind === 'flipper') {
                const f = n.ref;
                const tx = f.px + Math.cos(f.angle) * f.len;
                const ty = f.py + Math.sin(f.angle) * f.len;
                this._segBasis(n.model, f.px, f.py, tx, ty, FLIPPER_H_SIM, (f.r + 1) * 1.6);
            }
        }
        // Balls (multiball) — position each active ball, hide the rest.
        const r = cam.ws(state.ballR);
        for (let k = 0; k < this._ballNodes.length; k++) {
            const node = this._ballNodes[k];
            const bb = state.balls[k];
            node.visible = !!bb;
            if (bb) fromScaleTranslate(node.model, r, r, r, cam.wx(bb.x), r, cam.wz(bb.y));
        }
    }

    /** Spawn a collision spark burst at the contact point, tinted by dimension. */
    _onCollision(e) {
        if (!this.cam || !this._particles) return;
        const cam = this.cam;
        const dd = DIMENSIONS[e.dimension] ?? DIMENSIONS.matter;
        const col = hexToRgb(dd.palette.accent);
        const force = Math.min(1, (e.force ?? 0) / 1200);
        const base = (e.objectType === 'bumper' || e.objectType === 'slingshot') ? 16 : 8;
        const count = Math.round((base + force * 18) * (dd.particleDensity ?? 1));
        this._particles.spawn(
            [cam.wx(e.x), cam.ws(18), cam.wz(e.y)],
            col,
            { count, speed: 1.5 + force * 4, size: 0.06, life: 0.6, spread: 0.85, dir: [e.nx, 0.7, e.ny] },
        );
    }

    /** Big radial plasma burst when the particle-dimension charge surges. */
    _onPlasma(e) {
        if (!this.cam || !this._particles) return;
        const cam = this.cam;
        const col = hexToRgb(DIMENSIONS.particle.palette.core);
        this._particles.spawn([cam.wx(e.x), cam.ws(20), cam.wz(e.y)], col, { count: 150, speed: 6, size: 0.085, life: 1.1, spread: 1.0 });
    }

    /** Swirl burst when the ball completes an orbit around a gravity well. */
    _onOrbit(e) {
        if (!this.cam || !this._particles) return;
        const cam = this.cam;
        const col = hexToRgb(DIMENSIONS.gravity.palette.core);
        const n = 24 + Math.min(e.combo ?? 1, 5) * 14;
        this._particles.spawn([cam.wx(e.x), cam.ws(16), cam.wz(e.y)], col, { count: n, speed: 3.2, size: 0.07, life: 0.9, spread: 1.0 });
    }

    /** Golden ring of sparks when a hit lands on the resonance beat. */
    _onResonance(e) {
        this._reson = 1; // spike the spectral shimmer
        if (!this.cam || !this._particles) return;
        const cam = this.cam;
        const n = 10 + Math.min(e.combo ?? 1, 8) * 8;
        this._particles.spawn([cam.wx(e.x), cam.ws(16), cam.wz(e.y)], [1.0, 0.95, 0.7], { count: n, speed: 2.6 + (e.combo ?? 0) * 0.4, size: 0.07, life: 0.8, spread: 1.0 });
    }

    destroy() {
        this._unsub?.();
        this._unsubP?.();
        this._unsubO?.();
        this._unsubR?.();
        this._unsubReactor?.();
        this._particles?.destroy();
        this._core?.destroy();
        this._depthTex?.destroy?.();
        this._frameBuf?.destroy?.();
        this._objBuf?.destroy?.();
        for (const m of Object.values(this._meshes)) m?.destroy?.();
        this._meshes = {}; this._nodes = []; this._built = false;
    }
}

function normalize3(x, y, z) {
    const l = Math.hypot(x, y, z) || 1;
    return [x / l, y / l, z / l];
}

function hexToRgb(hex) {
    const n = parseInt(String(hex).replace('#', ''), 16) || 0;
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
}

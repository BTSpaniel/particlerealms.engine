/**
 * ModelMatrix helpers for the pinball 3D renderer — only the two builders that
 * aren't in the engine math lib. All general matrix/camera math (multiply,
 * lookAt, WebGPU perspective) is reused from engine/core/math/EngineMath.js
 * (see TableCamera.js). Column-major Float32Array(16), matching EngineMath and
 * WGSL `mat4x4<f32>`.
 */

/**
 * Build a model matrix from an orthonormal-ish basis (each axis already scaled
 * to the desired half/full extent) plus a translation. Columns are the axes.
 * @param {Float32Array} out
 * @param {number[]} xAxis [x,y,z] — local +X (scaled)
 * @param {number[]} yAxis [x,y,z] — local +Y (scaled)
 * @param {number[]} zAxis [x,y,z] — local +Z (scaled)
 * @param {number[]} t     [x,y,z] — translation
 */
export function fromBasis(out, xAxis, yAxis, zAxis, t) {
    out[0]=xAxis[0]; out[1]=xAxis[1]; out[2]=xAxis[2]; out[3]=0;
    out[4]=yAxis[0]; out[5]=yAxis[1]; out[6]=yAxis[2]; out[7]=0;
    out[8]=zAxis[0]; out[9]=zAxis[1]; out[10]=zAxis[2]; out[11]=0;
    out[12]=t[0]; out[13]=t[1]; out[14]=t[2]; out[15]=1;
    return out;
}

/** Axis-aligned scale + translation (for radially-symmetric meshes). */
export function fromScaleTranslate(out, sx, sy, sz, tx, ty, tz) {
    out[0]=sx; out[1]=0; out[2]=0; out[3]=0;
    out[4]=0; out[5]=sy; out[6]=0; out[7]=0;
    out[8]=0; out[9]=0; out[10]=sz; out[11]=0;
    out[12]=tx; out[13]=ty; out[14]=tz; out[15]=1;
    return out;
}

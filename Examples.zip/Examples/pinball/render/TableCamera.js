/**
 * TableCamera.js — maps the logical playfield into 3D world space and builds the
 * readability-first, top-down-favored pinball camera (TDD §6).
 *
 * Logical sim space: x ∈ [0,PW] (right), y ∈ [0,PH] (+y = down the table toward
 * the flippers/drain). World space: X right, Z depth (+Z = bottom/near the
 * camera), Y up (height above the playfield surface). The camera sits above and
 * in front of the bottom edge, tilted down so the whole table is visible with a
 * touch of depth while keeping the ball and flippers legible.
 */
import { mat4Multiply, mat4LookAt, mat4PerspectiveRadWebGPU } from '../../../../engine/core/math/EngineMath.js';

export const WORLD_SCALE = 0.045; // logical px → world units

export class TableCamera {
    constructor(PW, PH) {
        this.PW = PW; this.PH = PH;
        this._proj = null;
        this._view = null;        // camera (tilted-world → camera)
        this._viewTilt = null;    // flat-table-space → camera (= view · tilt)
        this._viewProj = null;
        this.eye = [0, 0, 0];
        // Real pinball cabinets incline the playfield; the player views it from a
        // low camera at the front looking UP the slope. These match that.
        this._tilt = 28 * Math.PI / 180; // playfield incline (rises toward the back)
        this._fovy = 48 * Math.PI / 180;
        this._near = 0.4;
        this._far  = 200;
    }

    // ── Sim → world mapping (flat table space; the tilt is baked into viewProj) ──
    wx(x) { return (x - this.PW / 2) * WORLD_SCALE; }
    wz(y) { return (y - this.PH / 2) * WORLD_SCALE; }
    ws(v) { return v * WORLD_SCALE; }

    /** Recompute view-proj for the current surface aspect. Returns the matrix. */
    update(surfaceWidth, surfaceHeight) {
        const aspect = Math.max(0.0001, surfaceWidth / Math.max(1, surfaceHeight));
        const depth = this.ws(this.PH);   // total table depth in world units
        const halfD = depth / 2;          // bottom edge sits at world +Z = +halfD

        // Player viewpoint: low and behind the bottom edge, gazing up the slope so
        // the flippers are near/low and the table recedes upward into the distance.
        const camY = depth * 0.30;
        const camZ = halfD + depth * 0.50;
        this.eye = [0, camY, camZ];
        const target = [0, depth * 0.34, -depth * 0.05];

        this._proj = mat4PerspectiveRadWebGPU(this._fovy, aspect, this._near, this._far);
        this._view = mat4LookAt(this.eye, target, [0, 1, 0]);

        // Tilt the whole table about its bottom edge (z = +halfD). This inclines
        // every node, the ball, and the particles together — and keeps walls
        // perpendicular to the playfield — purely as a baked-in world transform.
        const tilt = tiltAboutXAtZ(this._tilt, halfD);
        this._viewTilt = mat4Multiply(this._view, tilt);
        this._viewProj = mat4Multiply(this._proj, this._viewTilt);
        this._tiltPivot = halfD; // remember for flat-space camera reconstruction
        return this._viewProj;
    }

    get viewProj() { return this._viewProj; }

    /** Camera right/up axes in flat-table space (rows of view·tilt) for billboards. */
    get right() { const v = this._viewTilt; return v ? [v[0], v[4], v[8]] : [1, 0, 0]; }
    get up()    { const v = this._viewTilt; return v ? [v[1], v[5], v[9]] : [0, 1, 0]; }

    /**
     * Camera position in FLAT table space (the tilt is baked into viewProj, so
     * geometry lives un-tilted). Volumetric raymarchers reconstruct rays here.
     * Applies the inverse tilt (rotate −θ about X at the bottom-edge pivot) to eye.
     */
    get eyeFlat() {
        const [ex, ey, ez] = this.eye;
        const zP = this._tiltPivot ?? 0;
        const c = Math.cos(this._tilt), s = Math.sin(this._tilt);
        const zc = ez - zP;
        return [ex, c * ey + s * zc, -s * ey + c * zc + zP];
    }
}

/**
 * Column-major 4×4 that rotates points about the world X axis by `theta`,
 * pivoting at z = `zPivot` (the table's bottom edge), so the far end of the
 * playfield rises while the near edge stays on the ground plane.
 *
 *   x' = x
 *   y' = cosθ·y − sinθ·(z − zPivot)
 *   z' = sinθ·y + cosθ·(z − zPivot) + zPivot
 */
function tiltAboutXAtZ(theta, zPivot) {
    const c = Math.cos(theta), s = Math.sin(theta);
    return new Float32Array([
        1, 0, 0, 0,
        0, c, s, 0,
        0, -s, c, 0,
        0, s * zPivot, zPivot * (1 - c), 1,
    ]);
}

/**
 * GeometryFactory.js — unit primitive meshes for the 3D Reactor table.
 *
 * Reuses the engine's primitive generators (`createCubeGeometry` /
 * `createSphereGeometry` / `createCylinderGeometry`, all centered & Y-up) and
 * the engine's `createMesh` GPU upload path. The only local work is interleaving
 * the engine's separate position/normal arrays into the pos(3)+normal(3) layout
 * our forward pipeline expects. Primitives are unit-sized so the renderer scales
 * them per node:
 *   - box:      1×1×1 cube
 *   - cylinder: radius 1, height 1 (y ∈ [-0.5, 0.5])
 *   - sphere:   radius 1
 */
import { createMesh } from '../../../../engine/render/Mesh.js';
import {
    createCubeGeometry,
    createSphereGeometry,
    createCylinderGeometry,
} from '../../../../engine/render/geometry/PrimitiveGeometry.js';

const STRIDE = 24; // 6 floats × 4 bytes (pos3 + normal3)
const ATTRS = [
    { name: 'position', location: 0, offset: 0,  format: 'float32x3' },
    { name: 'normal',   location: 1, offset: 12, format: 'float32x3' },
];

/** Interleave engine geometry { positions, normals, indices } → a GPU mesh. */
function meshFromGeometry(device, label, geo) {
    const { positions, normals, indices } = geo;
    const n = positions.length / 3;
    const verts = new Float32Array(n * 6);
    for (let i = 0; i < n; i++) {
        verts[i*6+0] = positions[i*3+0];
        verts[i*6+1] = positions[i*3+1];
        verts[i*6+2] = positions[i*3+2];
        verts[i*6+3] = normals[i*3+0];
        verts[i*6+4] = normals[i*3+1];
        verts[i*6+5] = normals[i*3+2];
    }
    const big = indices.length > 65535;
    return createMesh(device, {
        id: label, label,
        vertexData: verts, vertexStride: STRIDE, attributes: ATTRS,
        indexData: big ? new Uint32Array(indices) : new Uint16Array(indices),
        indexFormat: big ? 'uint32' : 'uint16',
        topology: 'triangle-list',
    });
}

export function createBoxMesh(device) {
    return meshFromGeometry(device, 'pinball_box', createCubeGeometry(1));
}

export function createCylinderMesh(device) {
    return meshFromGeometry(device, 'pinball_cylinder', createCylinderGeometry(1, 1, 28, 1));
}

export function createSphereMesh(device) {
    return meshFromGeometry(device, 'pinball_sphere', createSphereGeometry(1, 28, 18));
}

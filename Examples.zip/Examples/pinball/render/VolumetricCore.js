/**
 * VolumetricCore.js — raymarched reactor-core orb (TDD §8.1, Phase 9).
 *
 * Renders a glowing volumetric energy sphere by raymarching an SDF *inside a
 * proxy bounding cube* drawn in the main depth-tested pass. Because the proxy is
 * real geometry sharing the table's depth buffer (depthCompare 'less', no depth
 * write), opaque geometry in front — a rail, a wall — naturally occludes the
 * volume via the depth test. This is what makes "portal behind rail respects
 * depth" hold without manually sampling the depth texture.
 *
 * The core lives in FLAT table space (the camera tilt is baked into viewProj),
 * so the fragment shader reconstructs the view ray from `camPos` (flat) to the
 * fragment's flat-space world position and analytically integrates the sphere
 * chord, modulated by animated noise and tinted by the active dimension's
 * spectral colour + reactor intensity.
 */
import { fromScaleTranslate } from './Mat4.js';

const SHADER = /* wgsl */`
struct U {
    model:    mat4x4<f32>,
    viewProj: mat4x4<f32>,
    camPos:   vec4<f32>,   // xyz = camera in flat table space
    center:   vec4<f32>,   // xyz = core centre, w = radius
    color:    vec4<f32>,   // rgb = spectral tint, w = intensity
    params:   vec4<f32>,   // x = time
};
@group(0) @binding(0) var<uniform> u: U;

struct VO { @builtin(position) pos: vec4<f32>, @location(0) world: vec3<f32> };

@vertex
fn vs(@location(0) p: vec3<f32>) -> VO {
    var o: VO;
    let w = (u.model * vec4<f32>(p, 1.0)).xyz;
    o.world = w;
    o.pos = u.viewProj * vec4<f32>(w, 1.0);
    return o;
}

fn hash(p: vec3<f32>) -> f32 {
    return fract(sin(dot(p, vec3<f32>(12.9898, 78.233, 37.719))) * 43758.5453);
}

@fragment
fn fs(i: VO) -> @location(0) vec4<f32> {
    let ro = u.camPos.xyz;
    let rd = normalize(i.world - ro);
    let ctr = u.center.xyz;
    let R = u.center.w;

    // Ray vs sphere — analytic chord length gives volumetric thickness.
    let oc = ro - ctr;
    let b = dot(oc, rd);
    let c = dot(oc, oc) - R * R;
    let h = b * b - c;
    if (h < 0.0) { discard; }
    let sh = sqrt(h);
    let t0 = max(-b - sh, 0.0);
    let t1 = -b + sh;
    if (t1 <= 0.0) { discard; }

    let thickness = clamp((t1 - t0) / (2.0 * R), 0.0, 1.0);

    // Churning energy: sample a few points along the chord for animated density.
    let t = u.params.x;
    var dens = 0.0;
    for (var k = 0; k < 4; k = k + 1) {
        let tt = mix(t0, t1, (f32(k) + 0.5) / 4.0);
        let sp = (ro + rd * tt - ctr) / R;
        let n = sin(sp.x * 6.0 + t * 1.7) * cos(sp.y * 5.0 - t * 1.3) * sin(sp.z * 6.0 + t);
        dens = dens + (0.5 + 0.5 * n);
    }
    dens = dens / 4.0;

    // Hot core, soft falloff toward the rim.
    let rim = 1.0 - thickness;
    let glow = thickness * (0.55 + 0.65 * dens);
    let col = u.color.rgb * u.color.w * glow + vec3<f32>(1.0, 0.97, 0.85) * pow(thickness, 3.0) * 0.5;
    let a = clamp(glow, 0.0, 0.95);
    return vec4<f32>(col * a, a); // premultiplied additive
}
`;

export class VolumetricCore {
    constructor(device, format) {
        this.device = device;
        this.format = format;
        this._pipeline = null;
        this._uni = null;
        this._bind = null;
        this._model = new Float32Array(16);
        this._data = new Float32Array(48); // 3 mat? no: 192 bytes / 4 = 48 floats
    }

    init() {
        const device = this.device;
        const mod = device.createShaderModule({ code: SHADER });
        this._pipeline = device.createRenderPipeline({
            layout: 'auto',
            vertex: {
                module: mod, entryPoint: 'vs',
                buffers: [{ arrayStride: 24, attributes: [{ shaderLocation: 0, offset: 0, format: 'float32x3' }] }],
            },
            fragment: { module: mod, entryPoint: 'fs', targets: [{
                format: this.format,
                blend: {
                    color: { srcFactor: 'one', dstFactor: 'one', operation: 'add' },
                    alpha: { srcFactor: 'one', dstFactor: 'one', operation: 'add' },
                },
            }] },
            primitive: { topology: 'triangle-list', cullMode: 'none' },
            depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'less' },
        });
        this._uni = device.createBuffer({ size: 192, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
        this._bind = device.createBindGroup({
            layout: this._pipeline.getBindGroupLayout(0),
            entries: [{ binding: 0, resource: { buffer: this._uni } }],
        });
    }

    /**
     * @param {GPURenderPassEncoder} pass
     * @param {object} mesh    proxy cube mesh ({vertexBuffer,indexBuffer,indexFormat,indexCount})
     * @param {Float32Array} viewProj
     * @param {number[]} camFlat   camera position in flat table space
     * @param {number[]} center    [x,y,z] core centre (flat space)
     * @param {number} radius
     * @param {number[]} color     [r,g,b] spectral tint
     * @param {number} intensity
     * @param {number} time
     */
    render(pass, mesh, viewProj, camFlat, center, radius, color, intensity, time) {
        if (!this._pipeline || !mesh) return;
        // Proxy cube: unit cube → scale to enclose the sphere (margin) + translate.
        const s = radius * 2.4;
        fromScaleTranslate(this._model, s, s, s, center[0], center[1], center[2]);

        const d = this._data;
        d.set(this._model, 0);
        d.set(viewProj, 16);
        d[32] = camFlat[0]; d[33] = camFlat[1]; d[34] = camFlat[2]; d[35] = 0;
        d[36] = center[0]; d[37] = center[1]; d[38] = center[2]; d[39] = radius;
        d[40] = color[0]; d[41] = color[1]; d[42] = color[2]; d[43] = intensity;
        d[44] = time; d[45] = 0; d[46] = 0; d[47] = 0;
        this.device.queue.writeBuffer(this._uni, 0, d);

        pass.setPipeline(this._pipeline);
        pass.setBindGroup(0, this._bind);
        pass.setVertexBuffer(0, mesh.vertexBuffer);
        pass.setIndexBuffer(mesh.indexBuffer, mesh.indexFormat);
        pass.drawIndexed(mesh.indexCount);
    }

    destroy() {
        this._uni?.destroy?.();
        this._uni = null; this._pipeline = null; this._bind = null;
    }
}

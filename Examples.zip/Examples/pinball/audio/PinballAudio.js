/**
 * PinballAudio — procedural SFX + per-dimension audio layering (TDD §13).
 *
 * Routes all game audio through the OS audio stack: it registers a single
 * 'game' session on the shared OS AudioContext (so it shows up in the Sound
 * mixer and obeys master/per-app volume) and synthesizes every cue with
 * oscillators/noise — no asset files. A soft two-oscillator drone retunes on
 * each DIMENSION_SHIFT so every reality has its own tonal bed, and impact cues
 * are pitched from that reality's root, so the same bumper "sounds" matter vs
 * particle vs shadow.
 *
 * Everything no-ops safely before the first user gesture / when audio is
 * unavailable, and per-cue throttling stops rapid hits from machine-gunning.
 */
import { PinballEvents } from '../core/PinballEventBus.js';

// Per-dimension tonal identity: root pitch, oscillator timbre, drone interval.
const DIM_AUDIO = {
    matter:   { root: 220, type: 'triangle', drone: [55, 82.4],  cutoff: 1400 },
    particle: { root: 330, type: 'sine',     drone: [98, 147],   cutoff: 3200 },
    gravity:  { root: 165, type: 'sawtooth', drone: [41, 61.7],  cutoff: 900 },
    shadow:   { root: 196, type: 'square',   drone: [49, 58.3],  cutoff: 700 },
    chaos:    { root: 277, type: 'sawtooth', drone: [73, 110],   cutoff: 2000 },
};

export class PinballAudio {
    constructor(bus, audio) {
        this.bus = bus;
        this.audio = audio ?? null;     // syscalls.audio
        this.enabled = true;
        this._ctx = null;
        this._master = null;            // our session input gain
        this._session = null;
        this._drone = null;             // { oscA, oscB, filter, gain }
        this._dim = 'matter';
        this._last = {};                // per-cue throttle timestamps

        this._subs = [
            bus.on(PinballEvents.COLLISION, (e) => this._onCollision(e)),
            bus.on(PinballEvents.PLASMA_SURGE, () => this._arp(this._root() * 1.5, 5, 0.05, 'sine')),
            bus.on(PinballEvents.ORBIT, (e) => this._sweep(this._root(), this._root() * (1.5 + 0.2 * (e.combo || 1)), 0.4)),
            bus.on(PinballEvents.RESONANCE, (e) => this._bell(this._root() * (2 + 0.25 * (e.combo || 1)), 0.5)),
            bus.on(PinballEvents.REACTOR_STATE, (e) => this._onReactor(e)),
            bus.on(PinballEvents.DIMENSION_SHIFT, (e) => this._onDimension(e)),
            bus.on(PinballEvents.BALL_LAUNCHED, () => this._sweep(160, 720, 0.22, 'sawtooth', 0.12)),
            bus.on(PinballEvents.MISSION, (e) => this._onMission(e)),
        ];
    }

    setEnabled(on) {
        this.enabled = !!on;
        if (!on) this._stopDrone();
        else if (this._ctx) this._startDrone();
    }

    // ── Context / graph ──────────────────────────────────────────────────────────

    _ensure() {
        if (this._ctx) return this._ctx;
        const a = this.audio;
        if (!a?.available?.()) return null;
        const ctx = a.context?.();
        if (!ctx) return null;
        this._ctx = ctx;
        this._master = ctx.createGain();
        this._master.gain.value = 0.6;
        try {
            this._session = a.registerSession({ appId: 'os.pinball', kind: 'game', label: 'Dimensional Pinball', icon: '\uD83C\uDFAF' });
            a.attachNode(this._session, this._master);
        } catch { try { this._master.connect(ctx.destination); } catch {} }
        try { a.resume?.(); } catch {}
        this._startDrone();
        return ctx;
    }

    _root() { return (DIM_AUDIO[this._dim] ?? DIM_AUDIO.matter).root; }

    // ── Synth primitives ───────────────────────────────────────────────────────────

    _tone({ freq, type = 'sine', dur = 0.1, gain = 0.18, attack = 0.004, slideTo = null, when = 0 }) {
        const ctx = this._ensure();
        if (!ctx || !this.enabled) return;
        const t0 = ctx.currentTime + 0.001 + when;
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(Math.max(20, freq), t0);
        if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t0 + dur);
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.exponentialRampToValueAtTime(gain, t0 + attack);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
        osc.connect(g); g.connect(this._master);
        osc.start(t0); osc.stop(t0 + dur + 0.02);
    }

    _noise(dur = 0.12, gain = 0.2, cutoff = 1200) {
        const ctx = this._ensure();
        if (!ctx || !this.enabled) return;
        const t0 = ctx.currentTime + 0.001;
        const n = Math.floor(ctx.sampleRate * dur);
        const buf = ctx.createBuffer(1, n, ctx.sampleRate);
        const d = buf.getChannelData(0);
        for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
        const src = ctx.createBufferSource(); src.buffer = buf;
        const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = cutoff;
        const g = ctx.createGain();
        g.gain.setValueAtTime(gain, t0);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
        src.connect(lp); lp.connect(g); g.connect(this._master);
        src.start(t0); src.stop(t0 + dur + 0.02);
    }

    _arp(base, steps, step, type) {
        for (let i = 0; i < steps; i++) this._tone({ freq: base * Math.pow(1.18, i), type, dur: 0.12, gain: 0.13, when: i * step });
    }

    _sweep(from, to, dur, type = 'sine', gain = 0.16) { this._tone({ freq: from, slideTo: to, type, dur, gain }); }
    _bell(freq, dur) { this._tone({ freq, type: 'sine', dur, gain: 0.16 }); this._tone({ freq: freq * 2.01, type: 'sine', dur: dur * 0.7, gain: 0.06 }); }

    _throttle(key, ms) {
        const now = (this._ctx ? this._ctx.currentTime * 1000 : performance.now());
        if (now - (this._last[key] ?? -1e9) < ms) return false;
        this._last[key] = now; return true;
    }

    // ── Drone (per-dimension tonal bed) ────────────────────────────────────────────

    _startDrone() {
        const ctx = this._ctx;
        if (!ctx || this._drone || !this.enabled) return;
        const cfg = DIM_AUDIO[this._dim] ?? DIM_AUDIO.matter;
        const oscA = ctx.createOscillator(); oscA.type = 'sine'; oscA.frequency.value = cfg.drone[0];
        const oscB = ctx.createOscillator(); oscB.type = 'sine'; oscB.frequency.value = cfg.drone[1];
        const filter = ctx.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.value = cfg.cutoff;
        const gain = ctx.createGain(); gain.gain.value = 0.05;
        oscA.connect(filter); oscB.connect(filter); filter.connect(gain); gain.connect(this._master);
        oscA.start(); oscB.start();
        this._drone = { oscA, oscB, filter, gain };
    }

    _retuneDrone() {
        if (!this._drone || !this._ctx) return;
        const cfg = DIM_AUDIO[this._dim] ?? DIM_AUDIO.matter;
        const t = this._ctx.currentTime, d = this._drone;
        d.oscA.frequency.exponentialRampToValueAtTime(cfg.drone[0], t + 0.4);
        d.oscB.frequency.exponentialRampToValueAtTime(cfg.drone[1], t + 0.4);
        d.filter.frequency.exponentialRampToValueAtTime(cfg.cutoff, t + 0.4);
    }

    _stopDrone() {
        if (!this._drone) return;
        try { this._drone.oscA.stop(); this._drone.oscB.stop(); } catch {}
        try { this._drone.gain.disconnect(); } catch {}
        this._drone = null;
    }

    // ── Event handlers ───────────────────────────────────────────────────────────

    _onCollision(e) {
        const root = this._root();
        switch (e.objectType) {
            case 'bumper':    if (this._throttle('bumper', 35)) this._tone({ freq: root * 1.5, type: 'square', dur: 0.08, gain: 0.14 }); break;
            case 'target':    if (this._throttle('target', 40)) this._tone({ freq: root * 2, type: 'triangle', dur: 0.1, gain: 0.13 }); break;
            case 'slingshot': if (this._throttle('sling', 30)) this._tone({ freq: root * 2.5, type: 'square', dur: 0.05, gain: 0.10 }); break;
            case 'flipper':   if (this._throttle('flip', 45)) this._tone({ freq: root * 0.6, type: 'sine', dur: 0.06, gain: 0.10 }); break;
            case 'lock':      this._sweep(root * 2, root, 0.3, 'sine', 0.16); break;
            default: break;
        }
    }

    _onReactor(e) {
        if (e.newState === 'meltdown') { this._noise(0.5, 0.35, 1800); this._sweep(120, 40, 0.7, 'sawtooth', 0.22); }
        else {
            const level = { stable: 1, charged: 1.25, unstable: 1.5, critical: 1.9 }[e.newState] ?? 1;
            this._tone({ freq: this._root() * level, type: 'sine', dur: 0.22, gain: 0.14 });
        }
    }

    _onDimension(e) {
        this._dim = e.to ?? 'matter';
        this._noise(0.18, 0.12, 2400);
        this._sweep(this._root() * 0.7, this._root() * 1.6, 0.3, 'sine', 0.14);
        this._retuneDrone();
    }

    _onMission(e) {
        if (e.status === 'complete') this._arp(this._root(), 3, 0.09, 'sine');
        else if (e.status === 'wizard') { this._arp(this._root(), 6, 0.08, 'triangle'); this._bell(this._root() * 3, 0.6); }
    }

    destroy() {
        for (const u of this._subs) u?.();
        this._subs = [];
        this._stopDrone();
        if (this._session && this.audio) { try { this.audio.releaseSession(this._session); } catch {} }
        this._session = null; this._master = null; this._ctx = null;
    }
}

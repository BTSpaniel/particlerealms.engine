/**
 * PinballApp — Dimensional Pinball (WebGPU OS `gpu-panel` app).
 *
 * Phase 1: assembles the authoritative sim (PinballSimWorld) + input + event
 * bus + HUD and runs a playable Matter table. Gameplay is drawn by the Canvas-2D
 * PlayfieldRenderer2D so the feel can be tuned effect-free (TDD Phase 1 exit);
 * the kernel WebGPU surface is acquired and held for the Phase 2 engine 3D
 * renderer, which will replace the 2D overlay. Later phases add dimensions,
 * resonance, spectral color, raymarched voxels, the reactor, chaos multiball,
 * the OS audio stack, and the AGI train-as-you-play difficulty layer.
 *
 * Controls: Z/← left flipper, //→ right flipper, Space launch (hold to charge).
 */
import { PinballEventBus, PinballEvents } from './core/PinballEventBus.js';
import { PinballSimWorld } from './core/PinballSimWorld.js';
import { PinballInput } from './core/PinballInput.js';
import { DimensionManager } from './core/DimensionManager.js';
import { ResonanceSystem } from './core/ResonanceSystem.js';
import { ReactorSystem } from './core/ReactorSystem.js';
import { MissionSystem } from './core/MissionSystem.js';
import { AdaptiveAI } from './ai/AdaptiveAI.js';
import { PinballAudio } from './audio/PinballAudio.js';
import { getDimension } from './core/Dimensions.js';
import { PlayfieldRenderer2D } from './render/PlayfieldRenderer2D.js';
import { TableRenderer3D } from './render/TableRenderer3D.js';

const HISCORE_KEY = 'pinball/highscore.json';

// Reactor state → HUD colour (calm blue → hot red as the core destabilises).
const REACTOR_COLORS = Object.freeze({
    stable: '#7fd4ff', charged: '#5effc8', unstable: '#ffd24a',
    critical: '#ff8a3a', meltdown: '#ff4d4d',
});

export default class PinballApp {
    constructor(opts = {}) {
        this._root      = opts.root ?? null;
        this._syscalls  = opts.syscalls ?? null;
        this._host      = opts.host ?? null;
        this._surface   = null;
        this._canvas    = null;
        this._hud       = null;
        this._scoreEl   = null;
        this._ballsEl   = null;
        this._bus       = null;
        this._sim       = null;
        this._dim       = null;
        this._dimEl     = null;
        this._input     = null;
        this._renderer  = null;
        this._inputTarget = null;
        this._mode      = '2d';
        this._resizeObs = null;
        this._raf       = 0;
        this._last      = 0;
        this._destroyed = false;
    }

    async mount(container, syscalls, host) {
        this._root      = container;
        this._syscalls  = syscalls ?? this._syscalls;
        this._host      = host ?? this._host;
        this._destroyed = false;

        container.style.cssText =
            'position:relative;width:100%;height:100%;overflow:hidden;background:#05070b;' +
            'font-family:Inter,system-ui,sans-serif;color:#e8f0ff;';

        // gpu-panel apps receive a kernel-allocated WebGPU surface before mount.
        this._surface = this._syscalls?.gpu?.getSurface?.() ?? null;

        // Sim + events (renderer-agnostic).
        this._bus = new PinballEventBus();
        if (this._syscalls?.ipc) this._bus.bridgeToIpc(this._syscalls.ipc);
        this._sim = new PinballSimWorld(this._bus);
        this._dim = new DimensionManager(this._sim, this._bus);
        this._resonance = new ResonanceSystem(this._sim, this._bus);
        this._reactor = new ReactorSystem(this._sim, this._bus);
        this._missions = new MissionSystem(this._sim, this._bus, this._reactor);
        this._ai = new AdaptiveAI(this._sim, this._bus, { storage: this._syscalls?.storage ?? null });
        this._audio = new PinballAudio(this._bus, this._syscalls?.audio ?? null);

        // Renderer: 3D on the kernel GPU surface when available; 2D canvas fallback.
        // Input rides a transparent focusable overlay above the GPU canvas (3D) or
        // the 2D canvas itself.
        let target = null;
        if (this._surface?.device && this._surface?.context) {
            const overlay = document.createElement('div');
            overlay.tabIndex = 0;
            overlay.style.cssText = 'position:absolute;inset:0;z-index:2;outline:none;cursor:default;touch-action:none;';
            container.appendChild(overlay);
            try {
                const r = new TableRenderer3D(this._surface, this._bus);
                await r.init();
                this._renderer = r; this._mode = '3d'; target = overlay;
            } catch (e) {
                console.warn('[Pinball] 3D renderer init failed; using 2D fallback:', e?.message ?? e);
                overlay.remove();
            }
        }
        if (!this._renderer) {
            const canvas = document.createElement('canvas');
            canvas.tabIndex = 0;
            canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;z-index:2;outline:none;cursor:default;';
            container.appendChild(canvas);
            this._canvas = canvas; this._renderer = new PlayfieldRenderer2D(canvas);
            this._mode = '2d'; target = canvas;
            this._bindResize(container, canvas);
        }
        this._inputTarget = target;

        this._buildHud(container);
        this._loadHighScore();
        this._applySettings();
        this._input = new PinballInput(this._sim, target, { cycleDimension: () => this._dim.cycle() });
        // Real user input yields the table back from the attract auto-player.
        this._noteInput = () => this._ai?.noteUserInput();
        target.addEventListener('keydown', this._noteInput);
        target.addEventListener('pointerdown', this._noteInput);

        // HUD reacts to gameplay facts.
        this._bus.on(PinballEvents.SCORE, (e) => { if (this._scoreEl) this._scoreEl.textContent = 'Score: ' + e.score.toLocaleString(); });
        this._bus.on(PinballEvents.GAME_STATE, (e) => {
            if (this._ballsEl) this._ballsEl.textContent = 'Balls: ' + e.balls;
            if (e.state === 'lost') this._checkHighScore();
        });
        this._bus.on(PinballEvents.DIMENSION_SHIFT, (e) => {
            const d = getDimension(e.to);
            if (this._dimEl) { this._dimEl.textContent = d.name; this._dimEl.style.color = d.palette.primary; }
            if (this._chargeWrap) this._chargeWrap.style.opacity = e.to === 'particle' ? '1' : '0.28';
        });
        this._bus.on(PinballEvents.CHARGE, (e) => {
            if (!this._chargeFill) return;
            this._chargeFill.style.width = Math.round(e.charge * 100) + '%';
        });
        this._bus.on(PinballEvents.RESONANCE, (e) => {
            if (this._scoreEl) this._scoreEl.textContent = 'Score: ' + this._sim.score.toLocaleString();
            if (!this._beatEl) return;
            this._beatEl.style.background = '#fff3b0';
            this._beatEl.animate(
                [{ transform: 'scale(1)' }, { transform: 'scale(2.1)' }, { transform: 'scale(1)' }],
                { duration: 320, easing: 'ease-out' },
            );
            setTimeout(() => { if (this._beatEl) this._beatEl.style.background = '#39d7ff'; }, 320);
        });
        this._bus.on(PinballEvents.REACTOR_STATE, (e) => {
            if (!this._reactorEl) return;
            const c = REACTOR_COLORS[e.newState] ?? '#7fd4ff';
            this._reactorEl.textContent = 'Reactor: ' + e.newState.toUpperCase();
            this._reactorEl.style.color = c;
            this._reactorEl.style.textShadow = '0 0 8px ' + c;
            if (e.newState === 'meltdown') {
                if (this._scoreEl) this._scoreEl.textContent = 'Score: ' + this._sim.score.toLocaleString();
                this._reactorEl.animate(
                    [{ transform: 'scale(1)' }, { transform: 'scale(1.5)' }, { transform: 'scale(1)' }],
                    { duration: 600, easing: 'ease-out' },
                );
            }
        });
        this._bus.on(PinballEvents.MISSION, (e) => {
            if (this._scoreEl) this._scoreEl.textContent = 'Score: ' + this._sim.score.toLocaleString();
            if (!this._missionEl) return;
            this._missionEl.textContent = (e.status === 'wizard' ? '★ ' : 'Mission: ') + e.title;
            this._missionEl.style.color = e.wizardReady ? '#ffd24a' : '#a9b8d0';
            if (e.status === 'complete' || e.status === 'wizard') {
                this._missionEl.animate(
                    [{ opacity: 0.3 }, { opacity: 1 }], { duration: 400, easing: 'ease-out' },
                );
            }
        });
        this._bus.on(PinballEvents.PLASMA_SURGE, (e) => {
            if (this._scoreEl) this._scoreEl.textContent = 'Score: ' + this._sim.score.toLocaleString();
            if (!this._chargeWrap) return;
            this._chargeWrap.animate(
                [{ boxShadow: '0 0 0 0 rgba(31,210,180,0.0)' }, { boxShadow: '0 0 16px 4px rgba(31,210,180,0.9)' }, { boxShadow: '0 0 0 0 rgba(31,210,180,0.0)' }],
                { duration: 700, easing: 'ease-out' },
            );
        });

        // Focus gating: only respond to keys while the game is focused.
        this._input.active = false;
        target.addEventListener('focus', () => { this._input.active = this._sim.state !== 'lost'; });
        target.addEventListener('blur',  () => { this._input.active = false; });
        target.addEventListener('pointerdown', () => {
            target.focus();
            if (this._sim.state === 'lost') this._sim.newGame();
        });
        this._input.attach();
        target.focus();

        this._startLoop();
    }

    _buildHud(container) {
        const hud = document.createElement('div');
        hud.style.cssText =
            'position:absolute;top:0;left:0;right:0;z-index:3;display:flex;gap:18px;align-items:center;' +
            'padding:7px 14px;font-size:13px;color:rgba(232,240,255,0.92);pointer-events:none;' +
            'background:linear-gradient(180deg,rgba(5,7,11,0.66),transparent);text-shadow:0 1px 2px rgba(0,0,0,0.6);';
        const score = document.createElement('span'); score.textContent = 'Score: 0';
        const balls = document.createElement('span'); balls.textContent = 'Balls: 3';
        const dim   = document.createElement('span');
        dim.textContent = 'Matter';
        dim.style.cssText = 'font-weight:600;color:#cfd8e6;';
        // Charge meter (Particle dimension): fills from hits, fires a plasma surge at full.
        const chargeWrap = document.createElement('div');
        chargeWrap.title = 'Particle charge';
        chargeWrap.style.cssText = 'width:84px;height:7px;border-radius:4px;background:rgba(255,255,255,0.12);overflow:hidden;opacity:0.28;transition:opacity .25s;';
        const chargeFill = document.createElement('div');
        chargeFill.style.cssText = 'width:0%;height:100%;border-radius:4px;background:linear-gradient(90deg,#39d7ff,#1fd2b4);transition:width .12s linear;';
        chargeWrap.appendChild(chargeFill);
        // Resonance beat dot — pulses with the reactor oscillator; flashes gold on a phase-match.
        const beat = document.createElement('div');
        beat.title = 'Reactor resonance — hit on the beat';
        beat.style.cssText = 'width:9px;height:9px;border-radius:50%;background:#39d7ff;opacity:0.25;box-shadow:0 0 6px rgba(57,215,255,0.8);';
        // Reactor state pill.
        const reactor = document.createElement('span');
        reactor.textContent = 'Reactor: STABLE';
        reactor.style.cssText = 'font-weight:600;color:#7fd4ff;text-shadow:0 0 8px #7fd4ff;';
        // Adaptive-AI pill: live skill estimate + ADAPTIVE/ATTRACT state.
        const ai = document.createElement('span');
        ai.title = 'Adaptive difficulty — learns from your play';
        ai.textContent = 'AI 40%';
        ai.style.cssText = 'font-weight:600;color:#9d7bff;';
        const hint  = document.createElement('span');
        hint.textContent = 'Z/← · //→ · Space launch · X shift';
        hint.style.cssText = 'margin-left:auto;color:rgba(169,184,208,0.7);font-size:11px;';
        // Best (persisted high score).
        const best = document.createElement('span');
        best.textContent = 'Best: 0';
        best.style.cssText = 'color:#ffd24a;font-weight:600;';
        hud.append(score, best, balls, dim, chargeWrap, beat, reactor, ai, hint);
        // Mission objective line (second row, full width).
        const mission = document.createElement('div');
        mission.textContent = 'Mission: Power Up — score 5,000';
        mission.style.cssText = 'flex-basis:100%;font-size:12px;color:#a9b8d0;letter-spacing:0.02em;';
        hud.append(mission);
        hud.style.flexWrap = 'wrap';
        container.appendChild(hud);
        this._hud = hud; this._scoreEl = score; this._ballsEl = balls; this._dimEl = dim;
        this._chargeWrap = chargeWrap; this._chargeFill = chargeFill; this._beatEl = beat;
        this._reactorEl = reactor; this._missionEl = mission; this._aiEl = ai; this._bestEl = best;
    }

    // ── High-score persistence (syscalls.storage, localStorage fallback) ─────────
    async _loadHighScore() {
        this._highScore = 0;
        const st = this._syscalls?.storage;
        try {
            if (st?.readJSON) { const v = await st.readJSON(HISCORE_KEY); if (v && Number.isFinite(v.best)) this._highScore = v.best; }
            else if (typeof localStorage !== 'undefined') { const v = JSON.parse(localStorage.getItem(HISCORE_KEY) || 'null'); if (v && Number.isFinite(v.best)) this._highScore = v.best; }
        } catch { /* no save yet */ }
        if (this._bestEl) this._bestEl.textContent = 'Best: ' + this._highScore.toLocaleString();
    }

    // ── Per-app settings (os.appSettings VFS, namespaced by appId) ────────────────
    async _applySettings() {
        let cfg = {};
        try {
            const raw = await this._syscalls?.fs?.read?.('os.appSettings');
            if (raw) cfg = (JSON.parse(raw)['os.pinball']) ?? {};
        } catch { /* defaults */ }
        // Adaptive difficulty toggle — off reverts the table to neutral physics.
        if (cfg.adaptiveDifficulty === false) this._ai?.setEnabled(false);
        // High-contrast ball outline (accessibility).
        if (cfg.highContrastBall === true && this._renderer?.setHighContrastBall) {
            this._renderer.setHighContrastBall(true);
        }
        this._settings = cfg;
    }

    _checkHighScore() {
        const score = this._sim?.score ?? 0;
        if (score <= (this._highScore ?? 0)) return;
        this._highScore = score;
        if (this._bestEl) this._bestEl.textContent = 'Best: ' + score.toLocaleString();
        const st = this._syscalls?.storage;
        try {
            if (st?.writeJSON) st.writeJSON(HISCORE_KEY, { best: score });
            else if (typeof localStorage !== 'undefined') localStorage.setItem(HISCORE_KEY, JSON.stringify({ best: score }));
        } catch { /* ignore */ }
    }

    _bindResize(container, canvas) {
        const apply = () => {
            const dpr = Math.min(2, window.devicePixelRatio || 1);
            const w = Math.max(1, Math.floor(container.clientWidth  * dpr));
            const h = Math.max(1, Math.floor(container.clientHeight * dpr));
            if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
        };
        apply();
        if (typeof ResizeObserver !== 'undefined') {
            this._resizeObs = new ResizeObserver(apply);
            this._resizeObs.observe(container);
        }
    }

    _startLoop() {
        this._last = performance.now();
        const tick = (now) => {
            if (this._destroyed) return;
            this._raf = requestAnimationFrame(tick);
            const dt = Math.min(0.05, (now - this._last) / 1000);
            this._last = now;
            try {
                // The attract auto-player and human input must not fight over the
                // flippers — while attract is driving, the human handler stands down.
                const attract = !!this._ai?.attract?.enabled;
                this._input.active = !attract && this._sim.state !== 'lost' && document.activeElement === this._inputTarget;
                if (!attract) this._input.update();
                this._sim.step(dt);
                this._resonance.update(dt);
                this._reactor.update(dt);
                this._ai.update(now);
                if (this._aiEl) {
                    const pct = Math.round(this._ai.skill.skill * 100);
                    const txt = (attract ? 'ATTRACT ' : 'AI ') + pct + '%';
                    if (txt !== this._aiText) { this._aiEl.textContent = txt; this._aiEl.style.color = attract ? '#ffb84a' : '#9d7bff'; this._aiText = txt; }
                }
                if (this._beatEl) this._beatEl.style.opacity = (0.25 + this._resonance.beat * 0.75).toFixed(3);
                this._renderer.render(this._sim.getState(), this._input.charge);
            } catch (e) { /* keep the loop alive across transient errors */ }
        };
        this._raf = requestAnimationFrame(tick);
    }

    unmount() {
        this._destroyed = true;
        cancelAnimationFrame(this._raf);
        this._raf = 0;
        this._input?.detach();
        this._resonance?.destroy();
        this._reactor?.destroy();
        this._missions?.destroy();
        this._ai?.destroy();
        this._audio?.destroy();
        if (this._inputTarget && this._noteInput) {
            this._inputTarget.removeEventListener('keydown', this._noteInput);
            this._inputTarget.removeEventListener('pointerdown', this._noteInput);
        }
        this._bus?.clear();
        this._resizeObs?.disconnect();
        this._resizeObs = null;
        this._renderer?.destroy?.();
        this._inputTarget?.remove();
        this._canvas?.remove();
        this._hud?.remove();
        this._canvas = null; this._hud = null; this._inputTarget = null;
        this._sim = null; this._input = null; this._renderer = null; this._bus = null;
        try { this._syscalls?.gpu?.releaseSurface?.(); } catch { /* desktop may already release */ }
        this._surface = null;
        this._root = null;
    }
}

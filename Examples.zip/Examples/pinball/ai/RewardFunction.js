/**
 * RewardFunction — the difficulty-controller's per-ball reward (TDD §12 §9.3).
 *
 * The actuator's goal is NOT to maximize the player's score — it's to keep the
 * player in a target *challenge band*: long enough balls to feel competent, but
 * not so long they coast. The reward is highest when the ball's survival time
 * lands near a skill-scaled target, with a small bonus for resonance engagement
 * (the player using the timing system) and a penalty for instant drains.
 *
 * Returned values sit roughly in [-1..1] — a clean signal for REINFORCE.
 */
export class RewardFunction {
    constructor(opts = {}) {
        this.baseTarget = opts.baseTarget ?? 14; // seconds at mid skill
        this.spread = opts.spread ?? 10;          // tolerance band (s)
    }

    /**
     * @param {object} ball  { survivalSec, points, bestCombo, resonanceHits }
     * @param {number} skill [0..1]
     */
    evaluate(ball, skill = 0.5) {
        // Skilled players get a higher survival target (they should be pushed).
        const target = this.baseTarget + skill * 16; // 14s..30s
        const surv = ball.survivalSec ?? 0;
        const z = (surv - target) / this.spread;
        let r = Math.exp(-0.5 * z * z) * 2 - 1;       // Gaussian band, peak +1 at target

        if (surv < 3) r -= 0.5;                        // instant drain = bad balance
        r += 0.15 * Math.min(1, (ball.resonanceHits ?? 0) / 4); // engagement bonus
        return Math.max(-1.5, Math.min(1.2, r));
    }
}

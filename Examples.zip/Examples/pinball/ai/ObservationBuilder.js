/**
 * ObservationBuilder — the RL observation vector for the adaptive systems (TDD §12).
 *
 * Builds two flavours from the authoritative sim state:
 *   - `frame(state)`: a per-frame, normalized control observation used by the
 *     attract auto-player's policy (ball kinematics relative to each flipper,
 *     plus context).
 *   - `context(skill, telemetry)`: the slow per-ball feature vector the
 *     difficulty controller conditions on.
 *
 * All values are normalized to roughly [-1..1] so a small linear policy is
 * well-conditioned without feature scaling surprises.
 */
export class ObservationBuilder {
    constructor(PW, PH) { this.PW = PW; this.PH = PH; }

    /** Per-frame control observation (primary ball vs flippers + context). */
    frame(state, skill = 0.5) {
        const b = state.balls?.[0];
        const PW = this.PW, PH = this.PH;
        if (!b) return [0, 0, 0, 0, 0, 0, 0, skill * 2 - 1];
        const nx = (b.x / PW) * 2 - 1;
        const ny = (b.y / PH) * 2 - 1;
        const nvx = clampSym(b.vx / 1800);
        const nvy = clampSym(b.vy / 1800);
        // Distance to each flipper tip region (lower-left / lower-right).
        const dL = dist(b.x, b.y, PW * 0.33, PH - 70) / PH;
        const dR = dist(b.x, b.y, PW * 0.67, PH - 70) / PH;
        const launched = b.launched ? 1 : -1;
        return [nx, ny, nvx, nvy, clampSym(1 - dL * 2), clampSym(1 - dR * 2), launched, skill * 2 - 1];
    }

    /** Per-ball difficulty-controller context features (bias-first). */
    context(skill, telemetry = {}) {
        return [
            1,                                       // bias
            clampSym(skill * 2 - 1),                 // skill
            clampSym((telemetry.lastSurvival ?? 12) / 25 - 1), // recent survival vs ~25s
            clampSym((telemetry.recentDrainRate ?? 0.08) * 4 - 1), // drains/sec proxy
        ];
    }
}

function dist(ax, ay, bx, by) { return Math.hypot(ax - bx, ay - by); }
function clampSym(v) { return Math.min(1, Math.max(-1, Number.isFinite(v) ? v : 0)); }

/**
 * ExperienceBuffer — fixed-capacity ring of training transitions (TDD §12).
 *
 * Each entry is one "episode" (one ball): the context features the controller
 * acted on, the latent action it sampled, the policy mean/std at action time,
 * and the realized reward. The PPO/REINFORCE trainer samples minibatches from
 * here between balls. Fixed capacity → bounded memory, no per-push allocation
 * churn beyond the entry object.
 */
export class ExperienceBuffer {
    constructor(capacity = 256) {
        this.capacity = capacity;
        this._buf = [];
        this._head = 0;
    }

    get size() { return this._buf.length; }

    push(entry) {
        if (this._buf.length < this.capacity) this._buf.push(entry);
        else this._buf[this._head] = entry;
        this._head = (this._head + 1) % this.capacity;
    }

    /** Uniform-random minibatch (with replacement) for a training step. */
    sample(n) {
        const out = [];
        const len = this._buf.length;
        if (len === 0) return out;
        for (let i = 0; i < n; i++) out.push(this._buf[(Math.random() * len) | 0]);
        return out;
    }

    clear() { this._buf.length = 0; this._head = 0; }
}

/**
 * AdaptiveAI — orchestrates the train-as-you-play difficulty layer (TDD §12).
 *
 * Wiring:
 *   - SkillEstimator      ← per-ball telemetry (survival, scoring rate, combos)
 *   - ObservationBuilder  → per-ball context features for the controller
 *   - DifficultyController → samples a difficulty per ball, learns from reward,
 *                            and the chosen multipliers are pushed to the sim
 *   - AttractPlayer       → competent demo play when the player goes idle
 *
 * Episode boundaries are a "ball-in-play life": a life is consumed (lives drop)
 * → the ball ends → reward → learn. Ball-saves and multiball drains don't end the
 * episode (lives unchanged). Training is time-sliced a couple of minibatches per
 * frame so it never hitches. Policy + skill persist via `syscalls.storage`.
 */
import { PW, PH } from '../core/PinballSimWorld.js';
import { PinballEvents } from '../core/PinballEventBus.js';
import { SkillEstimator } from './SkillEstimator.js';
import { ObservationBuilder } from './ObservationBuilder.js';
import { DifficultyController } from './DifficultyController.js';
import { AttractPlayer } from './AttractPlayer.js';

const STORE_KEY = 'pinball/adaptive-ai.json';
const IDLE_MS = 15000;     // go to attract after this much no-input
const SAVE_EVERY_MS = 12000;

export class AdaptiveAI {
    constructor(sim, bus, opts = {}) {
        this.sim = sim;
        this.bus = bus;
        this.storage = opts.storage ?? null;

        this.enabled = opts.enabled !== false; // adaptive difficulty + attract on by default
        this.skill = new SkillEstimator();
        this.obs = new ObservationBuilder(PW, PH);
        this.controller = new DifficultyController();
        this.attract = new AttractPlayer(sim);

        this.telemetry = { lastSurvival: 12, recentDrainRate: 0.08 };
        this._inEpisode = false;
        this._epStart = 0;
        this._epScore0 = 0;
        this._bestCombo = 1;
        this._resHits = 0;
        this._prevLives = sim.ballsLeft;
        this._lastInputAt = nowMs();
        this._lastSaveAt = nowMs();

        this._subs = [
            bus.on(PinballEvents.BALL_LAUNCHED, () => this._onLaunch()),
            bus.on(PinballEvents.GAME_STATE, (e) => this._onGameState(e)),
            bus.on(PinballEvents.RESONANCE, (e) => { this._resHits++; this._bestCombo = Math.max(this._bestCombo, e.combo || 1); }),
        ];

        this._load();
    }

    /** Enable/disable the adaptive layer (manifest setting). Disabled = neutral sim. */
    setEnabled(on) {
        this.enabled = !!on;
        if (!on) {
            this.sim.setDifficulty({ kick: 1, gravity: 1, flipper: 1, saveSec: 0 });
            this.attract.setEnabled(false);
        }
    }

    /** PinballApp calls this on real user input so attract yields to the player. */
    noteUserInput() {
        this._lastInputAt = nowMs();
        if (this.attract.enabled) this.attract.setEnabled(false);
    }

    update(now) {
        if (!this.enabled) return;   // skill still tracked via events; no actuation/attract/training
        // Attract activation: idle long enough (or sitting on game-over) → demo.
        const idle = now - this._lastInputAt > IDLE_MS;
        if (idle && !this.attract.enabled) this.attract.setEnabled(true);
        if (this.attract.enabled) this.attract.update(now);

        // Time-sliced on-device training (cheap; only runs when work is queued).
        this.controller.trainTick(2);

        if (now - this._lastSaveAt > SAVE_EVERY_MS) { this._lastSaveAt = now; this._save(); }
    }

    // ── Episode lifecycle ──────────────────────────────────────────────────────

    _onLaunch() {
        if (this._inEpisode) return;        // multiball / post-save launches stay in-episode
        this._inEpisode = true;
        this._epStart = nowMs();
        this._epScore0 = this.sim.score;
        this._bestCombo = 1;
        this._resHits = 0;
        if (this.enabled) {
            const ctx = this.obs.context(this.skill.skill, this.telemetry);
            this.sim.setDifficulty(this.controller.beginBall(ctx));
        }
    }

    _onGameState(e) {
        const lives = e.balls;
        if (Number.isFinite(lives)) {
            if (lives < this._prevLives) this._endEpisode();   // a life was consumed
            else if (lives > this._prevLives) { this._inEpisode = false; } // new game served
            this._prevLives = lives;
        }
        if (e.state === 'lost') this._endEpisode();
    }

    _endEpisode() {
        if (!this._inEpisode) return;
        this._inEpisode = false;
        const survivalSec = Math.max(0, (nowMs() - this._epStart) / 1000);
        const points = Math.max(0, this.sim.score - this._epScore0);
        const stats = { survivalSec, points, bestCombo: this._bestCombo, resonanceHits: this._resHits };

        this.skill.recordBall(stats);
        this.telemetry.lastSurvival = survivalSec;
        this.telemetry.recentDrainRate += 0.3 * ((survivalSec > 0 ? 1 / survivalSec : 1) - this.telemetry.recentDrainRate);
        this.controller.endBall(stats, this.skill.skill);
    }

    // ── Persistence ──────────────────────────────────────────────────────────────

    async _load() {
        const o = await loadJSON(this.storage, STORE_KEY);
        if (!o) return;
        try { this.skill.load(o.skill); this.controller.load(o.controller); } catch { /* ignore corrupt */ }
    }

    _save() {
        const payload = { skill: this.skill.toJSON(), controller: this.controller.toJSON() };
        saveJSON(this.storage, STORE_KEY, payload);
    }

    destroy() {
        this._save();
        this.attract.setEnabled(false);
        for (const u of this._subs) u?.();
        this._subs = [];
    }
}

function nowMs() { return (typeof performance !== 'undefined' ? performance.now() : Date.now()); }

async function loadJSON(storage, key) {
    // Prefer the OS persistent storage (OPFS); fall back to localStorage.
    if (storage && typeof storage.readJSON === 'function') {
        try { const v = await storage.readJSON(key); if (v != null) return v; } catch { /* missing/denied */ }
    }
    if (storage && typeof storage.read === 'function') {
        try { return parse(await storage.read(key)); } catch { /* missing/denied */ }
    }
    try { if (typeof localStorage !== 'undefined') return parse(localStorage.getItem(key)); } catch { /* ignore */ }
    return null;
}

function saveJSON(storage, key, obj) {
    if (storage && typeof storage.writeJSON === 'function') {
        try { storage.writeJSON(key, obj); return; } catch { /* fall through */ }
    }
    if (storage && typeof storage.write === 'function') {
        try { storage.write(key, JSON.stringify(obj)); return; } catch { /* fall through */ }
    }
    try { if (typeof localStorage !== 'undefined') localStorage.setItem(key, JSON.stringify(obj)); } catch { /* ignore */ }
}

function parse(v) {
    if (v == null) return null;
    if (typeof v === 'object') return v;
    try { return JSON.parse(v); } catch { return null; }
}

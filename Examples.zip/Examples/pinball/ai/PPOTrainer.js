/**
 * PPOTrainer — clipped-surrogate policy-gradient updates for the PolicyNetwork
 * (TDD §12). Operates on minibatches of episodes from the ExperienceBuffer.
 *
 * Each episode stored the context `x`, the sampled `action`, and the policy
 * `mean`/`std` AT ACTION TIME (the "old" policy), plus the realized `reward`.
 * A step computes:
 *   - advantage  A = reward − V(x)             (value head as baseline)
 *   - ratio      ρ = exp(logπ_new − logπ_old)
 *   - clipped PPO surrogate gradient on the policy mean (→ weights), on logStd,
 *     and an MSE gradient on the value head.
 *
 * It is intentionally cheap (a handful of dot products per sample) and is called
 * a few minibatches at a time between balls / on idle frames, so on-device
 * training never hitches the render loop.
 */
export class PPOTrainer {
    constructor(policy, opts = {}) {
        this.policy = policy;
        this.lr = opts.lr ?? 0.02;
        this.valueLr = opts.valueLr ?? 0.05;
        this.clip = opts.clip ?? 0.2;
        this.stdLr = opts.stdLr ?? 0.008;
        this.steps = 0;
    }

    /** One minibatch update from an array of episode records. */
    step(batch) {
        const p = this.policy, n = p.n;
        if (!batch || batch.length === 0) return 0;

        const gW = new Float64Array(n);
        const gV = new Float64Array(n);
        let gLogStd = 0;
        let totalLoss = 0;

        for (const e of batch) {
            const x = e.x;
            const v = p.value(x);
            const adv = e.reward - v;

            const meanNew = p.mean(x);
            const stdNew = p.std();
            const lpNew = p.logProb(e.action, meanNew, stdNew);
            const lpOld = Number.isFinite(e.logProb) ? e.logProb : p.logProb(e.action, e.mean, e.std);
            const ratio = Math.exp(Math.min(20, lpNew - lpOld));

            // Clipped surrogate: only flow gradient when unclipped (standard PPO).
            const clipped = ratio < 1 - this.clip || ratio > 1 + this.clip;
            const useGrad = !(clipped && ratio * adv > clamp(ratio, 1 - this.clip, 1 + this.clip) * adv);
            totalLoss += -Math.min(ratio * adv, clamp(ratio, 1 - this.clip, 1 + this.clip) * adv);

            if (useGrad) {
                const var_ = stdNew * stdNew;
                // d logπ / d mean = (a-μ)/σ² ; d mean/d w_i = (1-μ²) x_i
                const dMean = (e.action - meanNew) / var_;
                const sech2 = 1 - meanNew * meanNew;
                const coef = ratio * adv * dMean * sech2;
                for (let i = 0; i < n; i++) gW[i] += coef * x[i];
                // d logπ / d logStd = ((a-μ)²/σ²) − 1
                gLogStd += ratio * adv * (((e.action - meanNew) * (e.action - meanNew)) / var_ - 1);
            }

            // Value head: minimize (V(x) − reward)²  → grad 2(V−r) x_i
            const vErr = v - e.reward;
            for (let i = 0; i < n; i++) gV[i] += vErr * x[i];
        }

        const inv = 1 / batch.length;
        for (let i = 0; i < n; i++) {
            p.w[i]  += this.lr * gW[i] * inv;
            p.vw[i] -= this.valueLr * gV[i] * inv;
        }
        p.logStd += this.stdLr * gLogStd * inv;
        p.logStd = Math.max(Math.log(0.06), Math.min(Math.log(0.8), p.logStd));
        this.steps++;
        return totalLoss * inv;
    }
}

function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }

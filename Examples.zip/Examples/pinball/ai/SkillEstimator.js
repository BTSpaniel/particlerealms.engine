/**
 * SkillEstimator — live player-skill estimate from play telemetry (TDD §12).
 *
 * Folds a handful of gameplay signals into a single smoothed skill scalar in
 * [0..1] that the adaptive-difficulty controller observes:
 *   - survival time per ball (longer = more skilled)
 *   - scoring rate (points/second in play)
 *   - combo / resonance length (timing skill)
 *   - shot accuracy proxy (useful hits vs drains)
 *
 * Everything is an exponential moving average so the estimate tracks within a
 * session without thrashing. Serializable for cross-session persistence.
 */
export class SkillEstimator {
    constructor(init = null) {
        this.skill = 0.4;          // smoothed skill [0..1]
        this._survivalEMA = 12;    // seconds; typical ball time
        this._rateEMA = 800;       // points/sec
        this._comboEMA = 1;        // best recent combo length
        this._alpha = 0.25;        // EMA responsiveness per ball
        if (init) this.load(init);
    }

    /**
     * Record a completed ball.
     * @param {object} s  { survivalSec, points, bestCombo }
     */
    recordBall(s) {
        const a = this._alpha;
        this._survivalEMA += a * ((s.survivalSec ?? 0) - this._survivalEMA);
        const rate = (s.survivalSec > 0.5) ? (s.points ?? 0) / s.survivalSec : 0;
        this._rateEMA += a * (rate - this._rateEMA);
        this._comboEMA += a * ((s.bestCombo ?? 1) - this._comboEMA);

        // Normalize each signal to ~[0..1] against soft reference scales, blend.
        const nSurv  = clamp01(this._survivalEMA / 35);     // 35s ball = excellent
        const nRate  = clamp01(this._rateEMA / 6000);       // 6k pts/s = excellent
        const nCombo = clamp01((this._comboEMA - 1) / 6);   // 7-combo = excellent
        const target = 0.5 * nSurv + 0.3 * nRate + 0.2 * nCombo;
        this.skill += this._alpha * (target - this.skill);
        this.skill = clamp01(this.skill);
        return this.skill;
    }

    toJSON() {
        return { skill: this.skill, survivalEMA: this._survivalEMA, rateEMA: this._rateEMA, comboEMA: this._comboEMA };
    }

    load(o) {
        if (!o) return;
        if (Number.isFinite(o.skill)) this.skill = clamp01(o.skill);
        if (Number.isFinite(o.survivalEMA)) this._survivalEMA = o.survivalEMA;
        if (Number.isFinite(o.rateEMA)) this._rateEMA = o.rateEMA;
        if (Number.isFinite(o.comboEMA)) this._comboEMA = o.comboEMA;
    }
}

function clamp01(v) { return Math.min(1, Math.max(0, Number.isFinite(v) ? v : 0)); }

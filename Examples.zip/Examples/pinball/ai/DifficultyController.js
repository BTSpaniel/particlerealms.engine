/**
 * DifficultyController — the adaptive-difficulty brain (TDD §12).
 *
 * Wraps the Gaussian PolicyNetwork + PPOTrainer + ExperienceBuffer + reward into
 * a per-ball control loop. Each ball it samples a latent difficulty `D ∈ [-1,1]`
 * conditioned on the player's context (skill + recent telemetry), decodes it into
 * the sim's difficulty multipliers, and — after the ball ends — scores the choice
 * with the RewardFunction and learns from it. Training is queued and time-sliced
 * by the orchestrator so it never hitches the frame.
 *
 * Decode (higher D = harder):
 *   kick    = 1 + 0.18·D     livelier/chaotic bumpers
 *   gravity = 1 + 0.14·D     faster ball (steeper tilt)
 *   flipper = 1 − 0.12·D     weaker flips (less save power)
 *   saveSec = max(0, −D)·4   ball-save window only when easing off
 */
import { PolicyNetwork } from './PolicyNetwork.js';
import { PPOTrainer } from './PPOTrainer.js';
import { ExperienceBuffer } from './ExperienceBuffer.js';
import { RewardFunction } from './RewardFunction.js';

export class DifficultyController {
    constructor(init = null) {
        this.policy = new PolicyNetwork(4, init?.policy ?? null);
        this.trainer = new PPOTrainer(this.policy);
        this.buffer = new ExperienceBuffer(256);
        this.reward = new RewardFunction();
        this.D = 0;                 // current latent difficulty
        this._pending = null;       // episode awaiting its reward
        this._trainQueue = 0;       // queued minibatch steps (time-sliced)
    }

    decode(D) {
        return {
            kick: 1 + 0.18 * D,
            gravity: 1 + 0.14 * D,
            flipper: 1 - 0.12 * D,
            saveSec: D < 0 ? -D * 4 : 0,
        };
    }

    /** Start a ball: sample a difficulty action from context → sim params. */
    beginBall(context) {
        const r = this.policy.act(context);
        this.D = r.action;
        this._pending = { x: context.slice(), action: r.action, mean: r.mean, std: r.std, logProb: r.logProb, reward: 0 };
        return this.decode(r.action);
    }

    /** End a ball: score the action, store the transition, queue training. */
    endBall(ballStats, skill) {
        if (!this._pending) return;
        this._pending.reward = this.reward.evaluate(ballStats, skill);
        this.buffer.push(this._pending);
        this._pending = null;
        this._trainQueue += 6; // ~6 minibatch updates per ball, time-sliced
    }

    /** Run up to `maxSteps` queued minibatch updates (called on idle frames). */
    trainTick(maxSteps = 2) {
        let done = 0;
        while (this._trainQueue > 0 && done < maxSteps && this.buffer.size >= 8) {
            this.trainer.step(this.buffer.sample(16));
            this._trainQueue--; done++;
        }
        return done;
    }

    toJSON() { return { policy: this.policy.toJSON() }; }
    load(o) { if (o?.policy) this.policy.load(o.policy); }
}

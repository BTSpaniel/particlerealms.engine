/**
 * AttractPlayer — competent demo auto-player (TDD §12).
 *
 * Drives the flippers and plunger with a robust reactive heuristic so the table
 * plays a believable, competent game during attract/idle: auto-launches, flips
 * each flipper when a descending ball enters its reach on the correct side, and
 * restarts after a game over. The adaptive-difficulty policy stays live while it
 * plays, so the AI both demonstrates and keeps learning/adapting on its own play.
 *
 * (Flipper control is heuristic by design — a from-scratch learned controller
 * needs far more experience than a session to play competently, whereas this is
 * reliably good and is the standard approach for real-machine attract modes.)
 */
import { PW, PH } from '../core/PinballSimWorld.js';

export class AttractPlayer {
    constructor(sim) {
        this.sim = sim;
        this.enabled = false;
        this._launchAt = 0;
    }

    setEnabled(on) {
        if (this.enabled === on) return;
        this.enabled = on;
        if (!on) { this.sim.setFlipper('left', false); this.sim.setFlipper('right', false); }
    }

    update(now) {
        if (!this.enabled || !this.sim) return;
        const sim = this.sim;

        if (sim.state === 'lost') {        // restart the demo game
            if (!this._restartAt) this._restartAt = now + 2500;
            else if (now > this._restartAt) { sim.newGame(); this._restartAt = 0; }
            return;
        }
        this._restartAt = 0;

        const primary = sim.balls[0];
        if (primary && !primary.launched && sim.state === 'ready') {
            if (!this._launchAt) this._launchAt = now + 600;     // brief pause, then plunge
            else if (now > this._launchAt) { sim.launch(0.8 + Math.random() * 0.2); this._launchAt = 0; }
            return;
        }
        this._launchAt = 0;

        // Flip when a descending ball is within a flipper's reach on its side.
        const mid = PW * 0.5;
        for (const f of sim.flippers) {
            let press = false;
            const reach = f.len + 46;
            for (const bb of sim.balls) {
                if (!bb.launched) continue;
                const onSide = f.side === 'left' ? bb.x < mid + 24 : bb.x > mid - 24;
                const near = Math.hypot(bb.x - f.px, bb.y - f.py) < reach;
                const inBand = bb.y > f.py - 96 && bb.y < f.py + 26;
                if (bb.vy > 0 && onSide && near && inBand) { press = true; break; }
            }
            sim.setFlipper(f.side, press);
        }
    }
}

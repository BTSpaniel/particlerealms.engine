/**
 * PolicyNetwork — a small Gaussian linear policy over a latent difficulty scalar
 * (TDD §12). Conditioned on the context feature vector, it outputs a bounded mean
 * `μ = tanh(w·x)` and samples an action `a ~ N(μ, σ)`; `σ` is a learnable
 * exploration std (`logStd`). Kept deliberately tiny so updates are a few dozen
 * flops — trains as you play with zero frame impact and no GPU dependency.
 *
 * Also carries a linear value/baseline head (`vw`) used by the trainer for
 * advantage estimation. Fully serializable for cross-session persistence.
 */
export class PolicyNetwork {
    constructor(nFeat = 4, init = null) {
        this.n = nFeat;
        this.w = new Float64Array(nFeat);   // policy weights
        this.vw = new Float64Array(nFeat);  // value-head weights
        this.logStd = Math.log(0.45);       // exploration std
        this._spare = null;                 // Box–Muller cache
        if (init) this.load(init);
    }

    mean(x) {
        let s = 0;
        for (let i = 0; i < this.n; i++) s += this.w[i] * x[i];
        return Math.tanh(s);
    }

    value(x) {
        let s = 0;
        for (let i = 0; i < this.n; i++) s += this.vw[i] * x[i];
        return s;
    }

    std() { return Math.min(0.8, Math.max(0.06, Math.exp(this.logStd))); }

    /** Sample an action; returns the action plus the policy stats at sample time. */
    act(x) {
        const mean = this.mean(x);
        const std = this.std();
        const a = clampSym(mean + std * this._gauss());
        return { action: a, mean, std, logProb: this.logProb(a, mean, std) };
    }

    logProb(a, mean, std) {
        const v = std * std;
        return -0.5 * Math.log(2 * Math.PI * v) - ((a - mean) * (a - mean)) / (2 * v);
    }

    _gauss() {
        if (this._spare !== null) { const s = this._spare; this._spare = null; return s; }
        let u = 0, v = 0, r = 0;
        do { u = Math.random() * 2 - 1; v = Math.random() * 2 - 1; r = u * u + v * v; } while (r === 0 || r >= 1);
        const f = Math.sqrt(-2 * Math.log(r) / r);
        this._spare = v * f;
        return u * f;
    }

    toJSON() { return { w: Array.from(this.w), vw: Array.from(this.vw), logStd: this.logStd, n: this.n }; }

    load(o) {
        if (!o) return;
        if (Number.isFinite(o.n)) this.n = o.n;
        if (Array.isArray(o.w) && o.w.length === this.n) this.w = Float64Array.from(o.w);
        if (Array.isArray(o.vw) && o.vw.length === this.n) this.vw = Float64Array.from(o.vw);
        if (Number.isFinite(o.logStd)) this.logStd = o.logStd;
    }
}

function clampSym(v) { return Math.min(1, Math.max(-1, v)); }
